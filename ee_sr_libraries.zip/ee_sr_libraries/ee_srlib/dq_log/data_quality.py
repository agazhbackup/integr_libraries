from decimal import Decimal
import hashlib
import pyspark
from pyspark.sql import SparkSession
import pyspark.sql.functions as f
from datetime import datetime
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, LongType, DoubleType, DecimalType, ArrayType
from py4j.protocol import Py4JJavaError
import json
import jsonschema

from ee_srlib.dq_log.data_quality_conf import *
from ee_srlib.dq_log.data_quality_exceptions import *

from ee_srlib.global_metadata.GlobalMetadataHandler import GMH


# Create a Spark session
spark = SparkSession.getActiveSession()

"""
This Module has all the functions required to implement logging for Data Quality Library.
Logs the required results from a Data Quality check to he DQ Log Table.    
"""
class DataQuality:

    def __init__(self) -> None:
        """
        Initialization of Data Quality Class
        """
        pass

    
    @staticmethod
    def __prepare_log_entry(id : str,runId : datetime ,checkId : int,rowsProcessed: int,rowsFailed: int,result: str,failurePercentage: float,artefact :str, businessImpactPercentage: Decimal) -> dict:
        """
        Prepares an output dictionary with the values that need to be inserted into the DQ Log Table
        Args:
            id (str): Unique ID for each entry. Created using HASH
            runId (datetime): Timestamp, signifying the time of entry.
            checkId (int): Check ID from the DQ Registry Table. Acts as foreign key for log table.
            rowsProcessed (int): Number of rows processesed as part of DQ Check
            rowsFailed (int): Number of rows failed as part of the DQ Check
            result (str): Result Flag. ( 0 = Green Flag, 1=Warning Flag(Yellow/Orange Flag) 2=Error Flag (Red Flag) )
            failurePercentage (float): Percentage of row failures
            artefact (str): Optional Artifact of DQ Check results. This is additional to the Table generated on Databricks which would contain all the DQ Check results

        Returns:
            dict: Output Prepared Dictionary with all the values assigned to correct columns.
        """

        log_entry_dict = {
            "id" : id,
            "runId": runId,
            "checkId": checkId,
            "rowsProcessed": rowsProcessed,
            "rowsFailed" : rowsFailed,
            "result": result,
            "failurePercentage": failurePercentage,
            "businessImpactPercentage": businessImpactPercentage,
            "artifact": artefact
        }
        return log_entry_dict
    

    def __create_unique_id(self,id: int,run_id: datetime) -> str:
        """
        Generates unique_ID for id column in DQ log table.
        Args:
            id (int): check_id from the DQ Registry
            run_id (datetime): Current Timestamp

        Returns:
            str: Unique ID Generated using hash librry using id and run_id
        """
        m = hashlib.sha512()
        hash_string = (str(id)+str(run_id)).encode("utf-8")
        m.update(hash_string)
        uid = str(int(m.hexdigest(), 16))
        return uid
    

    @staticmethod
    def __create_filter_expr(filter_expr:dict,parameters : dict = None) -> str :
        """
        Create a filter expression for pyspark using the provided dictionary

        Sample Dicitonary would look like (schema can be referred from data_quality_conf)- 
            
            {	
                "filters": [
                {
                "column_name": "metric",
                "operator": "=",
                "column_value" : "sum_pos_unit_sales_qty"
                },
                {
                "column_name": "data_provider_code_part",
                "operator": "=",
                "column_value" : "cds_4160"
                },
                {
                "column_name": "run_date", 
                "column_type": "date",
                "operator": "=",
                "column_value" : "{max_run_date}"
                }
                ],
                "operator": "AND"

            }

        Using this dictionary, the function would allow creating a sql expression filter to filter data from the data frame

        Args:
            filter_expr (dict): dicitionary to parse for generating the filter expression

        Returns:
            str: generated sql filter expression to use with dataframes
        """
        filter_exprs = []
        print("Provided Parameters: "+ str(parameters))
        if not parameters:
            parameters = {}
        for filter_item in filter_expr['filters']:
            column_name = filter_item['column_name']
            operator = filter_item['operator']
            
            column_value = filter_item['column_value'].format(**parameters)
            column_type = filter_item.get('column_type')

            if column_type:
                if operator == 'IN':
                    filter_exprs.append(f"CAST({column_name} AS {column_type}) IN {tuple(column_value)}")
                else:
                    filter_exprs.append(f"CAST({column_name} AS {column_type}) {operator} '{column_value}'")
            else:
                if operator == 'IN':
                    filter_exprs.append(f"{column_name} IN {tuple(column_value)}")
                else:
                    filter_exprs.append(f"{column_name} {operator} '{column_value}'")
        
        filter_expr = f.expr(f" {filter_expr['operator']} ".join(filter_exprs))
        return filter_expr
    
    @staticmethod
    def __validate_parent_filter_column(filter_expression : str) -> dict :
      """
      Validate the parentFilter column to check for correct and required schema.

      Args:
          filter_expression (str): Filter expression to validate
      """

      #Check for valid dictionary in parentFilter column
      try:
          filters = json.loads(filter_expression)
      except json.JSONDecodeError :
          raise InvalidDictionaryInRegistryError( f"Invalid dictionary structure in parentFilters column for dq id: {dq_id}" )
      
      #Check for Schema for parentFilter colummn
      try:
          jsonschema.validate(filters, filterSchema)
      except jsonschema.ValidationError :
          raise InvalidSchemaForFilterColumn("Dictionary structure for parentFilter column doesnt match the expected structure, please refer to documentation or check for any errors")
      
      return filters
    
    @staticmethod
    def __validate_registry_result(registry_details : pyspark.sql.DataFrame, dq_id: str, application_id : str = None) -> None:
        """
        Validate the registry result to check single output.

        Args:
            registry_details (pyspark.sql.DataFrame): registry output dataframe
            dq_id (str) : check id of the dq check
-           application_id (str) : Application ID configured for the corresponding dq check in the DQ registry
        """
        count = registry_details.count()
        if count == 0: #Incase there are no records for the provided DQ ID, Raise an Exception
            raise DQMetadataError(f"No record for DQ ID {dq_id} and appId {application_id} found in registry table or it is not active")
        elif count > 1: #Incase more than one active entry received for the combination of application id and dq id
            raise DQMetadataError(f"More than one ACTIVE record for DQ ID {dq_id} and appId {application_id} found in registry table")

    
    def __prepare_dq_log(self,application_id: str,dq_id : int, rows_processed: int = 0, rows_failed: int = 0, artefact : str = None, business_impact_error_pct : float = None) -> pyspark.sql.dataframe:
        """
        Prepares the dataframe and validates the row for dq log entry

        Args:
            application_id (str): Application ID configured for the corresponding dq check in the DQ registry
            dq_id (int): Check ID Configured in the DQ Registry
            rows_processed (int): Number of rows processes as part of the check
            rows_failed (int): Number of rows failed as a result of the check
            artefact (str, optional): Optional Artifact over and above the output result table in databricks (eg - Sharepoint Excel File etc). Defaults to None.
            business_impact_pct (float, optional) : Optionally specify a custom value as per custom logic for indicating the error value in percentage 

        Returns:
            pyspark.sql.dataframe: Dataframe for dq log entry
        """
        try:
            registry_details = GMH.read_file(
                'dq_framework_registry'
            )
            registry_details = registry_details.filter(f"{dq_registry_id_col} = {dq_id}") \
                                .filter(f"{dq_registry_appId_col} = '{application_id}'") \
                                .filter(f"{dq_registry_active_col} = true")

            self.__validate_registry_result(registry_details,dq_id,application_id)
        except Exception as exc:
            raise exc

        registry_details = registry_details.first().asDict()
        id = registry_details[dq_registry_id_col]

        run_id = datetime.now()

        #Extracting the thresholds defined in DQ Registry
        warning_threshold = registry_details[dq_registry_warning_threshold_col]
        critical_threshold = registry_details[dq_registry_critical_threhold_col]
        
        #Assigning Result Flag by comparing Failure Percentage for Current DQ Check with Thresholds Configured in DQ Registry
        result = None
        
        #Casting to Decimal Required to format the value to the required precision for DecimalType(6,2)
        if rows_processed != 0: 
            row_failure_percentage = Decimal(rows_failed/rows_processed)*100
        else:
            row_failure_percentage = Decimal(0)

        print("Row Failure Percentage: "+ str(row_failure_percentage) )
        percentage = row_failure_percentage
        

        if business_impact_error_pct is not None and business_impact_error_pct != "":
            if not 0 <= float(business_impact_error_pct) <= 100:
                raise DQMetadataError("Parameter 'business_impact_error_pct' needs to be in between 0 and 100")
            percentage = Decimal(business_impact_error_pct)

        if critical_threshold == 100 and percentage ==  critical_threshold :
            result = red_signal_value

        if not result:
            if percentage > critical_threshold:
                result = red_signal_value
            elif percentage > warning_threshold:
                result = yellow_signal_value
            else:
                result = green_signal_value
            
        uid = self.__create_unique_id(id,run_id)

        if business_impact_error_pct is not None:
            business_impact_error_pct = Decimal(business_impact_error_pct)

        log_entry = self.__prepare_log_entry(uid,run_id,id,rows_processed,rows_failed,result,row_failure_percentage,artefact, business_impact_error_pct)


        log_schema = StructType([
                                    StructField("id", StringType(), True),
                                    StructField("runId", TimestampType(), True),
                                    StructField("checkId", LongType(), True),
                                    StructField("rowsProcessed", LongType(), True),
                                    StructField("rowsFailed", LongType(), True),
                                    StructField("result", StringType(), True),
                                    StructField("failurePercentage", DecimalType(6,2), True),
                                    StructField("businessImpactPercentage",DecimalType(11,8), True),
                                    StructField("artifact", StringType(), True)
                                ])

        logDf = spark.createDataFrame([log_entry],log_schema)
        return logDf


    
    def push_to_dq_log(self,application_id: str,dq_id : int, rows_processed: int = 0, rows_failed: int = 0, artefact : str = None, business_impact_error_pct : float = None) -> bool:
        """
        The main function used to push logs to the DQ Log Table

        Args:
            application_id (str): Application ID configured for the corresponding dq check in the DQ registry
            dq_id (int): Check ID Configured in the DQ Registry
            rows_processed (int): Number of rows processes as part of the check
            rows_failed (int): Number of rows failed as a result of the check
            artefact (str, optional): Optional Artifact over and above the output result table in databricks (eg - Sharepoint Excel File etc). Defaults to None.
            business_impact_pct (float, optional) : Optionally specify a custom value as per custom logic for indicating the error value in percentage 

        Returns:
            bool: True if Succeeded
        """

        logDf = self.__prepare_dq_log(application_id,
                                      dq_id, 
                                      rows_processed, 
                                      rows_failed, 
                                      artefact, 
                                      business_impact_error_pct)
        display(logDf)

        try:
            GMH.write_file(
                df=logDf,
                metadata_code='dq_framework_log',
                mode = 'append'
            )

        except Py4JJavaError as exc:
            #Catches the Delta Constrain Validation Errors and prevents these specific exceptions from raising any errors/exceptions and only prints the 
            if "DeltaInvariantViolationException" in str(exc.java_exception):
                print("Logs not written due to constraint validation:\n{}".format(
                    str(exc.java_exception)
                ))
            else:
                raise exc

        return True
    

    def batch_push_to_dq_log(self,logs : list[list]) -> None:
        """
        Function used to batch push multiple logs to the log table

        Args:
            logs (list): List of list wherein each elements within the log list has the following attributes in order - 
            application_id
            dq_id
            rows_processed
            rows_failed
            artefact
            business_impact_error_pct
        """
        
        all_logs = spark.createDataFrame([], schema="")
        for log in logs:
            logDf = self.__prepare_dq_log(*log)
            all_logs = all_logs.unionByName(logDf, allowMissingColumns= True)
        
        display(all_logs)
        try:
            GMH.write_file(
                df=all_logs,
                metadata_code='dq_framework_log',
                mode = 'append'
            )

        except Py4JJavaError as exc:
            #Catches the Delta Constrain Validation Errors and prevents these specific exceptions from raising any errors/exceptions and only prints the 
            if "DeltaInvariantViolationException" in str(exc.java_exception):
                print("Logs not written due to constraint validation:\n{}".format(
                    str(exc.java_exception)
                ))
            else:
                raise exc



    def get_parent_dq_results(self,application_id: str,dq_id : int,parameter_dict: dict = None) -> pyspark.sql.DataFrame:
        """
        Get the data quality results from parent DQ check by applying the filters configured in the DQ registry

        Args:
            application_id (str): application_id of the dq check
            dq_id (int): Check ID of the DQ Check
            parameter_dict (dict, optional): Optional parameter dict for any filter values that need to replaced at runtime 

        Returns:
            pyspark.sql.DataFrame: Return the filtered data frame from parent check output table
        """
        #Get parent dq and child dq details from registry.
        registry_details = GMH.read_file(
                'dq_framework_registry'
            )
        
        child_dq = registry_details.filter(f"{dq_registry_id_col} = {dq_id}") \
                                .filter(f"{dq_registry_appId_col} = '{application_id}'") \
                                .filter(f"{dq_registry_active_col} = true")
        
        self.__validate_registry_result(child_dq,dq_id,application_id)

        child_dq_row = child_dq.first().asDict()
        
        parent_dq_id = child_dq_row["parentId"]
        
      
        parent_dq = registry_details.filter(f"{dq_registry_id_col} = {parent_dq_id}") \
                                .filter(f"{dq_registry_active_col} = true")
        
        self.__validate_registry_result(parent_dq,parent_dq_id,application_id)
       

        parent_dq_row = parent_dq.first().asDict()

        parent_dq_output_result_table = parent_dq_row["outputTable"]

        
        if parent_dq_output_result_table is None or parent_dq_output_result_table.strip() == '':
            raise DQMetadataError("For getting data from parent checks, output table needs to be defined for the parent check")
    

        #Extract Filter dict
        filter_str = child_dq_row["parentFilters"]

        filters = self.__validate_parent_filter_column(filter_str)
        
        filter_expr = self.__create_filter_expr(filters,parameter_dict)
        
        output_df = spark.table(parent_dq_output_result_table).filter(
            filter_expr
        )

        return output_df

