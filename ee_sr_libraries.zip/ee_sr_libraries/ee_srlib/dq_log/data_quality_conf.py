dq_registry_db = "sdl_metadata_views"
dq_registry_table = "dq_framework_registry_vw"
dq_registry_table_location = "/mnt/blob/sdl/data-quality/dq_framework_registry"

dq_registry_id_col = "id"
dq_registry_appId_col = "appId"
dq_registry_active_col = "active"

dq_registry_warning_threshold_col = "warningThreshold"
dq_registry_critical_threhold_col = "criticalThreshold"



dq_log_table = "dq_framework_log_vw"
dq_log_table_location = "/mnt/blob/sdl/sdl-logs/dq_framework_log"



green_signal_value = 0 # Assigned when failedRows donot breach any threshold
yellow_signal_value = 1 # Assigned when failedRows breach the warning threshold
red_signal_value = 2 # Assigned when failedRows breach the critical threshold

#Schema for validation for filter column
filterSchema = {
  "$schema": "http://json-schema.org/draft-04/schema#",
  "type": "object",
  "properties": {
    "filters": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "column_name": {
            "type": "string"
          },
          "column_type": {
            "type": "string"
          },
          "operator": {
            "type": "string"
          },
          "column_value": {
            "type": "string"
          }
        },
        "required": ["column_name", "operator", "column_value"]
      }
    },
    "operator": {
      "type": "string"
    }
  },
  "required": ["filters", "operator"]
}

