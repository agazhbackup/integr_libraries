class DQMetadataError(Exception):
  "Raises an error when it is impossible to connect to the metadata in one of the available ways"

class InvalidDictionaryInRegistryError(Exception):
  "Raises an error when any of the dictionary type column in registry doesnt have a valid JSON/Dictionary Structure"

class InvalidSchemaForFilterColumn(Exception):
  "Raises an exception when the schema of dicitionary/JSON doesnt match the expected schema for parentFilter column"
