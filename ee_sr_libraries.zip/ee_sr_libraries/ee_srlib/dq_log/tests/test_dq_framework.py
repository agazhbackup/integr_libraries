# Databricks notebook source
from ee_srlib.dq_log.data_quality import DataQuality

# COMMAND ----------

from ee_srlib.dq_log.data_quality_exceptions import *

# COMMAND ----------

# MAGIC %sh pip install parameterized

# COMMAND ----------

import io
from datetime import datetime
import unittest
import pandas as pd
from parameterized import parameterized
from pyspark.sql import functions as f
from ee_srlib.global_metadata.GlobalMetadataHandler import GMH

# COMMAND ----------

class TestDataQuality(unittest.TestCase):

    application_id = "UnitTest"
    artefact = "testArtefact"
    dq_id = 9990 #warningThreshold 5, criticalThreshold 10
    dq_id_with_parent = 9991 #warningThreshold 0, #criticalThreshold 100 
    dq_ids_in_scope = [str(dq_id),str(dq_id_with_parent)]

    #Runs at the start of each test
    def setUp(self):

        self.dataQualityObj = DataQuality()
        self.today_date = datetime.now().strftime("%Y-%m-%d")

    #This method is called automtically when all test are executed
    @classmethod
    def tearDownClass(cls):
        # Clean up resources after each test
        sql_to_delete_records = f"Delete from sdl_logs_views.dq_framework_log_vw where checkId in ({(',').join(TestDataQuality.dq_ids_in_scope)}) "
        print(sql_to_delete_records)
        spark.sql(sql_to_delete_records)
        print("Cleaning up resources created for Unit Tests")

    def get_inserted_row(self,dq_id):

        df = GMH.read_file(
            metadata_code = "dq_framework_log"
        )

        df = df.withColumn("runId_date",f.to_date(f.col("runId")))
        df = df.filter(f.col("checkId") == dq_id).filter(
            f.col("runId_date") == self.today_date
        ).sort(f.desc(f.col("runId"))).first()

        return df



    #App_id, dq_id, rows_processed, rows_failed, artefact, business_impact_error_pct, function_output, result
    @parameterized.expand([
        #Scenario 1: Traditional Row based data quality without providing an artefact (artefact is NULL) and without provding business_impact_percentage. Warning Threshold Breached
        (application_id, dq_id, 100, 5, None, None,True,"1"), 

         #Scenario 2: Traditional Row based data quality without providing an artefact (artefact is NULL) and without provding business_impact_percentage. Critical Threshold Breached
        (application_id, dq_id, 100, 20, None, None,True,"2"),

        #Scenario 3: Traditional Row based data quality with an artefact (artefact is NULL) and without provding business_impact_percentage. Critical Threshold Breached
        (application_id, dq_id, 100, 20, artefact, None, True,"2"),

        #Scenario 4: Traditional Row based data quality with an artefact (artefact is NULL) and  provding business_impact_percentage in valid string. Critical Threshold Breached
        (application_id, dq_id, 100, 20, artefact, '0.13', True,"0"),

        #Scenario 5: Traditional Row based data quality with an artefact (artefact is NULL) and  provding business_impact_percentage in valid numeric. Critical Threshold Breached
        (application_id, dq_id, 100, 20, artefact, 1, True,"0")
    ])
    
    #Success Scenarios
    def test_scenario_1(self,app_id,dq_id,rows_processed,rows_failed,artefact,business_impact_error_pct,expected_result,result_flag):

        dataQualityObj = DataQuality()
        result = self.dataQualityObj.push_to_dq_log(
           app_id,
           dq_id,
           rows_processed,
           rows_failed,
           artefact,
           business_impact_error_pct
        )
        self.assertEqual(result, expected_result)

        df = self.get_inserted_row(dq_id)

        print(df["result"])

        self.assertEqual(df["result"],result_flag)

    
    @parameterized.expand([
        #Scenario 6: Traditional Row based data quality with an artefact (artefact is NULL) and  provding business_impact_percentage in invalid string. Critical Threshold Breached
        (application_id, dq_id, 100, 20, artefact, "abc", True,"0"),

        #Scenario 7: DQ ID doesnt exist in Registry
        ("application_id", 999999, 100, 20, artefact, "abc", True,"0"),

    ])
    #Failure Scenarios
    def test_scenario_2(self,app_id,dq_id,rows_processed,rows_failed,artefact,business_impact_error_pct,expected_result,result_flag):
        
        dataQualityObj = DataQuality()

        with self.assertRaises(Exception) as context:
            #Expect this function to always fail
            result = self.dataQualityObj.push_to_dq_log(
            app_id,
            dq_id,
            rows_processed,
            rows_failed,
            artefact,
            business_impact_error_pct
            )
        print(f"Exception raised was: {context.exception}")
    

if __name__ == "__main__":

    suite = unittest.TestLoader().loadTestsFromTestCase(TestDataQuality)
    result = unittest.TextTestRunner(verbosity=2).run(suite)

    if not result.wasSuccessful():
        dbutils.notebook.exit(0)
        raise Exception("One or more tests failed!")
    
    #Add dbutils.notebook.exit()
    print("All tests passed!")
    dbutils.notebook.exit(1)



