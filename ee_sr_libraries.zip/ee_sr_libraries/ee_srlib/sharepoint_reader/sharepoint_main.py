from .spclient import SPClient
import io
import asyncio
import nest_asyncio
import pandas as pd

nest_asyncio.apply()


class SharepointIngestion(SPClient):
    """
    This class is for interacting with Sharepoint, uploading and downloading files. And work with the file system.
    This class can use all methods of the parent class. Use the < session > variable to do this.

    Init parameters:
      username [str] : Login required for authentication
      password [str] : Password required for authentication
      site_type [str] : The type of site for interaction takes one of two parameters < 'onedrive' or 'sharepoint' >
    Main methods:

      upload_files_from_blob - This function is for uploading data from a blob to sharepoint.
      post_dataframe_to_sp -  This function uploads the dataframe to Sharepoint as a file whose type is specified in file_name.
      download_files_to_blob - This function downloads files with a specific mask to the blob.
      read_from_sharepoint - This function reads data from a Sharepoint file into a pandas dataframe.
      creating_smart_table - This function saves the dataframe on the sharepoint as a smart excel spreadsheet.

    Please use help(SharepointIngestion) for more information.
    """

    def __init__(self, username: str, password: str, site_type: str, timeout: int = 100) -> None:

        self.username = username
        self.password = password
        self.site_type = site_type
        self.timeout = timeout

        d_sites_map = {
            "onedrive": {
                "url": "https://pgone-my.sharepoint.com",
                "site_type": "personal",
            },
            "sharepoint": {"url": "https://pgone.sharepoint.com", "site_type": "sites"},
        }

        try:
            self.sp_url = d_sites_map[self.site_type]["url"]
            self.__url_method = d_sites_map[self.site_type]["site_type"]
        except KeyError:
            raise ValueError(
                f"Invalid site type: < {self.site_type} >. Must be 'onedrive' or 'sharepoint'."
            )

    def set_session(self, sharepoint_name: str) -> None:
        """
        This method starts a connection session to Sharepoint.
        Init parameters:
            sharepoint_name [str] : sharepoint directory name

        """
        return SPClient(
            self.username,
            self.password,
            f"/{self.__url_method}/{sharepoint_name}",
            self.sp_url,
            timeout=self.timeout
        )

    def site(self, sharepoint_name: str) -> str:
        return f"{self.sp_url}/{self.__url_method}/{sharepoint_name}"

    def server_relative_url(self, sharepoint_name: str, needed_folder: str) -> str:
        return f"/{self.__url_method}/{sharepoint_name}/{needed_folder}"

    def folder_url(self, ServerRelativeUrl: str) -> str:
        return f"{self.sp_url}/{ServerRelativeUrl}"

    def __check_path(self, needed_folder: str) -> None:
        if ("`" in needed_folder) | ("'" in needed_folder):
            raise ValueError(f"Folder path contains invalid symbol  < ' > or < ` >.")
        if (needed_folder[-1]) == "/":
            raise ValueError(f"Invalid folder path. The path must not end with < / >.")

    def __cheking_folder_existing(
            self, sharepoint_name: str, needed_folder: str
    ) -> bool:

        """
        This function is designed to check the presence of a folder in Sharepoint.

        Args:
          sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
          needed_folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
        Returns:
          folder_ex [bool] : The folder presence marker: True - present, False - absent.
        """
        _folder = (
            self.set_session(sharepoint_name)
            .session.get(
                f"{self.site(sharepoint_name)}/_api/web/GetFolderByServerRelativeUrl('{self.server_relative_url(sharepoint_name, needed_folder)}')"
            )
            .json()
        )
        folder_ex = True
        try:  # Checking for a folder on sharepoint
            _folder["Name"]
        except KeyError:
            folder_ex = False
        return folder_ex

    def __check_df_type(self, df) -> pd.core.frame.DataFrame:
        """
        This function checks what type the forwarded dataframe belongs to.
        If a PySpark dataframe is passed, it converts it to a Pandas dataframe.

        Args:
          df : Pandas | PySpark Dataframe for uploading.
        Returns:
          df [pd.core.frame.DataFram] : Pandas dataframe for uploading on sharepoint
        """
        if type(df) != pd.core.frame.DataFrame:
            try:  # Checking dataframe type. Spark df will be converted in pandas.
                df = df.toPandas()
                print("Spark df was converted to Pandas")
            except Exception:
                raise ValueErorr(
                    "Perhaps the dataframe is too large and cannot be converted to Pandas."
                )
        else:
            print("Pandas df - OK.")
        return df

    def __check_file_name(self, file_name: str, correct_formats=["xlsx", "csv", "parquet", "xlsm", "xlsb"]) -> str:

        """
        This function checks the filename for the content of the file type and the absence of moot characters.

        Args:
          file_name [str] : Name of the file to be processed
        Returns:
          data_format [str] : file format like [xlsx, xlsm, xlsb, csv, parquet]
        """
        data_format = file_name.split(".")[-1]
        if len(data_format) == 0:
            raise ValueError(
                f"Invalid file format: < format not specified >, must be {correct_formats}"
            )
        if data_format not in correct_formats:
            raise ValueError(
                f"Invalid file format < {data_format} >, must be {correct_formats}"
            )
        if ("`" in file_name) | ("'" in file_name):
            raise ValueError("File contains invalid symbol  < ' > or < ` >.")
        return data_format

    def folder_parcing(
            self,
            sharepoint_name: str,
            needed_folder: str,
            need_subfolders: bool = False,
    ) -> list[str]:

        """
        This function is designed to get information about the folders inside the transferred folder.
        Iterates through all folders within the passed path and gets information about all subfolders.

        Args:
          ServerRelativeUrl [str] : A pointer to a sharepoint item object. Use the < SharepointIngestion.ServerRelativeUrl > function to get information.
          site [str] : Individual site marker. For example: < https://pgone.sharepoint.com/sites/sharepoint_name/ >.
        Returns:
          [list[str]] : List of all existing subfolders.
        """
        if isinstance(need_subfolders, bool) and need_subfolders:
            max_lvl = 100
        else:
            max_lvl = 1
        folders_getted = self.set_session(sharepoint_name).ls(
            directory=needed_folder,
            max_lvl=max_lvl,
            attributes="ServerRelativeUrl",
            flatten=True,
            show_files=False,
        )
        return list(set([i["serverrelativeurl"] for i in folders_getted]))

    def files_parcing(
            self,
            sharepoint_name: str,
            needed_folder: str,
            need_subfolders: bool = False,
            file_name_or_mask: str = None
    ) -> list[str]:
        """Retrieves a list of file paths from a SharePoint directory.

        Args:
            self: The current instance of the class.
            sharepoint_name (str): The name of the SharePoint.
            needed_folder (str): The path of the folder in SharePoint to retrieve files from.
            need_subfolders (bool, optional): Flag indicating whether to include files from subfolders. Defaults to False.
            file_name_or_mask (str, optional): The name or mask of the file(s) to filter the results. Defaults to None.

        Returns:
            list[str]: A list of file paths matching the specified criteria.
        """

        if isinstance(need_subfolders, bool) and need_subfolders:
            max_lvl = 100
        else:
            max_lvl = 1
        files_getted = self.set_session(sharepoint_name).ls(
            directory=needed_folder,
            max_lvl=max_lvl,
            attributes="ServerRelativeUrl",
            flatten=True,
            show_dirs=False,
        )

        all_files = list(set([i["serverrelativeurl"] for i in files_getted]))
        
        if file_name_or_mask:
            return list(set([_ for _ in all_files if file_name_or_mask.replace("*", "") in _.split('/')[-1]]))

        else:
            return list(set([i["serverrelativeurl"] for i in files_getted]))

    def creating_folder(self, sharepoint_name: str, needed_folder: str) -> None:
        """
        This function creates a folder in Sharepoint if it does not exist.
        Attention, cannot create a pack in a folder that has not been created yet.

        Args:
          sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
          needed_folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
        """

        if not self.__cheking_folder_existing(sharepoint_name, needed_folder):
            folder_split = needed_folder.split("/")

            for ix in range(1, len(folder_split)):
                root_folder = "/".join(folder_split[: ix + 1])
                is_exist = self.__cheking_folder_existing(sharepoint_name, root_folder)
                if not is_exist:
                    self.set_session(sharepoint_name).create_folder(root_folder)
            print(f"FOLDER < {needed_folder} > CREATED")
        else:
            print(f"FOLDER < {needed_folder} > ALREADY EXIST")

    def df_bytecoding(
            self, df: pd.core.frame.DataFrame, file_format: str, **kwargs
    ) -> bytes:

        """
        This function converts the data from the dataframe to bytes or string (csv).

        Args:
          df [pd.core.frame.DataFrame] : Dataframe for uploading
          file_format [str] : file format like [xlsx, xlsm, xslb, csv, parquet]
        Kwargs:
          **kwargs : Additional parameters for to_excel or to_csv or to_parquet functions. Depends on the file format.
        Returns:
          bytes_feedback [bytes] : Data for uploading on sharepoint
        """

        if len(df) > 0:  # Coding df in bytes
            pdf = df.copy()

            d_formats = {
                "xlsx": pdf.to_excel,
                "csv": pdf.to_csv,
                "parquet": pdf.to_parquet,
            }
            bytes_buffer = io.BytesIO()
            d_formats[file_format](bytes_buffer, **kwargs)
            return bytes_buffer

        else:
            raise ValueError("Invalid parameters. Empty dataframe.")

    def upload_files_from_blob(
            self,
            sharepoint_name: str,
            needed_folder: str,
            file_name: str,
            blob_path: str,
    ) -> str:
        """
        This function is for uploading data from a blob to sharepoint.

        Args:
          sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
          needed_folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
          file_name [str] : Name of the file to be processed
          blob_path [str] : Blob path to folder where file located. For example: /dbfs/mnt/blob/lp/container/folder/subfolder/
        Returns:
          response [str] : The result link to file
        """
        self.__check_path(needed_folder)
        self.creating_folder(sharepoint_name, needed_folder)
        return self.set_session(sharepoint_name).save_file(
            f"{blob_path}{file_name}", f"{needed_folder}/{file_name}"
        )

    def post_dataframe_to_sp(
            self, df, sharepoint_name: str, needed_folder: str, file_name: str, **kwargs
    ) -> None:

        """
        This function uploads the dataframe to Sharepoint as a file whose type is specified in file_name.

        Args:
          df : Pandas | PySpark Dataframe for uploading.
          sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
          needed_folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
          file_name [str] : Name of the file to be processed. File format must be in [xlsx, csv, parquet]
        Kwargs:
          **kwargs : Additional parameters for to_excel or to_csv or to_parquet functions. Depends on the file format.
        """

        self.__check_path(needed_folder)
        df_type = self.__check_df_type(df)
        file_type = self.__check_file_name(file_name)
        bytes_back = self.df_bytecoding(df_type, file_type, **kwargs)
        self.creating_folder(sharepoint_name, needed_folder)
        return self.set_session(sharepoint_name).save_stream(
            bytes_back, f"{needed_folder}/{file_name}"
        )

    async def __download_file_to_blob(
            self, sharepoint_name: str, file_source_paths: list, blob_path: str
    ):
        tasks = []
        ses = self.set_session(sharepoint_name)
        for file_source in file_source_paths:
            coroutine = asyncio.to_thread(
                ses.load_file, file_source, download=True, target_dir=blob_path
            )
            task = asyncio.create_task(coroutine)
            tasks.append(task)
        return await asyncio.wait(tasks)

    def download_files_to_blob(
            self,
            sharepoint_name: str,
            needed_folder: str,
            file_name_or_mask: str,
            blob_path: str,
            need_subfolders: bool = False,
    ) -> list:

        """
        This function downloads files with a specific mask to the blob.
        Args:
          sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
          needed_folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
          file_name_or_mask [str] : The mask or the full name of the file by which the necessary files are selected
          blob_path [str] : Blob path to folder where file will be located. For example: /dbfs/mnt/blob/lp/container/folder/subfolder/
          need_subfolders [bool] : Marker needs to iterate through all subfolders in the folder. It is necessary to form a list of files.
        Returns:
          result [list] : A list with the results of each file download.
        """
        self.__check_path(needed_folder)
        if not self.__cheking_folder_existing(sharepoint_name, needed_folder):
            raise ValueError(
                "Error. Folder was not found. Check the path and account access to the folder."
            )

        files_to_work = self.files_parcing(
            sharepoint_name, needed_folder, need_subfolders=need_subfolders
        )
        files_to_download = list(
            set(
                [
                    _.replace(f"/{self.__url_method}/{sharepoint_name}/", "")
                    for _ in files_to_work
                    if file_name_or_mask.replace("*", "") in _
                ]
            )
        )

        if len(files_to_download) == 0:
            raise ValueError(
                "Error. Files were not found. Check the path and account access to the folder."
            )
        result = asyncio.run(
                self.__download_file_to_blob(
                    sharepoint_name, files_to_download, blob_path
                )
            )[0]
        print(f"{len(result)} Files was processed.")
        return result


    def read_from_sharepoint(
            self,
            sharepoint_name: str,
            needed_folder: str,
            file_name: str,
            **kwargs,
    ) -> pd.core.frame.DataFrame:

        """
        This function reads data from a Sharepoint file into a pandas dataframe.

        Args:
          sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
          needed_folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
          file_name [str] : Name of the file to be processed. File format must be in [xlsx, csv, parquet]
        Returns:
          result [pd.core.frame.DataFrame] : Data from sharepoint table
        """
        self.__check_path(needed_folder)
        file_format = self.__check_file_name(file_name)
        d_formats = {
            "xlsx": pd.read_excel,
            "xlsm": pd.read_excel,
            "xlsb": pd.read_excel,
            "csv": pd.read_csv,
            "parquet": pd.read_parquet,
        }

        content = self.set_session(sharepoint_name).load_file(
            f"{needed_folder}/{file_name}"
        )
        try:
            df = d_formats[file_format](content, **kwargs)
            return df
        except KeyError:
            raise ValueError(
                f"Invalid file format < {file_format} >, must be {d_formats.keys()}"
            )

    def creating_smart_table(
            self,
            df: pd.core.frame.DataFrame,
            sharepoint_name: str,
            needed_folder: str,
            file_name: str,
            table_name: str,
    ) -> None:

        """
        This function saves the dataframe on the sharepoint as a smart excel spreadsheet.

        Args:
          df [pd.core.frame.DataFrame] : dataframe for uploading
          sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
          needed_folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
          file_name [str] : uploading file name (For ex. < 'file_1.xlsx' >)
          table_name [str] : excel smart table name
        Kwargs:
          **kwargs : Additional parameters for read_excel or read_csv or read_parquet functions. Depends on the file format.
        Returns:
          data [pd.core.frame.DataFrame] : Data from a file to sharepoint
        """

        df = self.__check_df_type(df)
        self.__check_path(needed_folder)
        self.__check_file_name(file_name)
        self.creating_folder(sharepoint_name, needed_folder)

        # Create a Pandas Excel writer using XlsxWriter as the engine.
        bytes_buffer = io.BytesIO()
        with pd.ExcelWriter(bytes_buffer, engine="xlsxwriter") as writer:
            # Write the dataframe data to XlsxWriter. Turn off the default header and
            # index and skip one row to allow us to insert a user defined header.

            df.to_excel(
                writer, sheet_name=table_name, startrow=1, header=False, index=False
            )
            workbook = writer.book  # Get the xlsxwriter workbook and worksheet objects.
            worksheet = writer.sheets[table_name]
            (max_row, max_col) = df.shape  # Get the dimensions of the dataframe.
            column_settings = [
                {"header": column} for column in df.columns
            ]  # Create a list of column headers, to use in add_table().

            # Add the Excel table structure. Pandas will add the data.
            worksheet.add_table(
                0,
                0,
                max_row,
                max_col - 1,
                {"columns": column_settings, "name": table_name},
            )

            # Make the columns wider for clarity.
            worksheet.set_column(0, max_col - 1, 12)

        return self.set_session(sharepoint_name).save_stream(
            bytes_buffer, f"{needed_folder}/{file_name}"
        )

    def post_dataframes_to_several_excel_sheets(
            self, list_of_df: list, sheets: list, sharepoint_name: str, needed_folder: str, file_name: str, **kwargs
    ) -> None:

        """
        This function uploads several dataframes to Sharepoint as a single excel file with several sheets.

        Args:
            list_of_df: list of Pandas | PySpark Dataframe for uploading. ex: [df1, df2, df3]
            sheets: list of sheets names in str format. Len of list with sheet names must be equal to len of list with dataframes.
            sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
            needed_folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
            file_name [str] : Name of the file to be processed. File format must be in ["xlsx", "xlsm", "xlsb"]
        Kwargs:
            **kwargs : Additional parameters for to_excel functions.
        """
        self.__check_path(needed_folder)
        self.__check_file_name(file_name, correct_formats=["xlsx", "xlsm", "xlsb"])
        self.creating_folder(sharepoint_name, needed_folder)

        bytes_buffer = io.BytesIO()
        with pd.ExcelWriter(bytes_buffer) as writer:
            for position, dataframe in enumerate(list_of_df):
                dataframe.to_excel(writer, sheet_name=sheets[position], index=False, **kwargs)

        return self.set_session(sharepoint_name).save_stream(bytes_buffer, f"{needed_folder}/{file_name}")

    def get_shared_link_for_file(
            self, sharepoint_name: str, file_path: str
    ) -> str:

        """
        This function creates and returns shared link for file which is defined by file_url.

        Args:
            sharepoint_name [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sites/sharepoint_name/ >
            file_path [str] : Path to the file in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
        """
        # if full link provided, use it
        if file_path.startswith('https://'):
            relative_url = file_path
        else:
            relative_url = self.server_relative_url(sharepoint_name, file_path)

        return self.set_session(sharepoint_name).get_sharable_link(relative_url)
