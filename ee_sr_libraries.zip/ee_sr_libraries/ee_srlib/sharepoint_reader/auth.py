"""Authorization module."""

from datetime import datetime
from textwrap import dedent
from xml.etree import ElementTree
from requests.auth import AuthBase
import requests
import nest_asyncio


nest_asyncio.apply()

class Constants:
    """Store constant values."""

    HEADER_ACCEPT = "application/json"
    HEADER_CONTENT_TYPE = "application/x-www-form-urlencoded"
    MICROSOFT_STS_URL = "https://login.microsoftonline.com/extSTS.srf"


class SAMLAuth(AuthBase):
    """SAML authorization class."""

    SAML_TMPLT = dedent(
        """
    <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing"
    xmlns:u="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
        <s:Header>
            <a:Action s:mustUnderstand="1">http://schemas.xmlsoap.org/ws/2005/02/trust/RST/Issue</a:Action>
            <a:ReplyTo>
            <a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>
            </a:ReplyTo>
            <a:To s:mustUnderstand="1">https://login.microsoftonline.com/extSTS.srf</a:To>
            <o:Security s:mustUnderstand="1"
            xmlns:o="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
            <o:UsernameToken>
                <o:Username>[username]</o:Username>
                <o:Password>[password]</o:Password>
            </o:UsernameToken>
            </o:Security>
        </s:Header>
        <s:Body>
            <t:RequestSecurityToken xmlns:t="http://schemas.xmlsoap.org/ws/2005/02/trust">
            <wsp:AppliesTo xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy">
                <a:EndpointReference>
                <a:Address>[endpoint]</a:Address>
                </a:EndpointReference>
            </wsp:AppliesTo>
            <wsp:PolicyReference xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy"
            URI="MBI"></wsp:PolicyReference>
            <t:KeyType>http://schemas.xmlsoap.org/ws/2005/05/identity/NoProofKey</t:KeyType>
            <t:RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</t:RequestType>
            <t:TokenType>urn:oasis:names:tc:SAML:1.0:assertion</t:TokenType>
            </t:RequestSecurityToken>
        </s:Body>
    </s:Envelope>"""
    )

    def __init__(self, url, username, password, proxies=None, timeout=100):
        """The SAMLAuth class object initialization.

        Args:
            url(str): connection url
            username(str): user email address
            password(str): user password
            proxies(dict, optional): connection proxy
        """
        self.url = url
        self.username = username
        self.password = password
        self.timeout = timeout

        # External Security Token Service for SPO
        self.sts = Constants.MICROSOFT_STS_URL
        # Sign in page url
        self.login = "/_forms/default.aspx?wa=wsignin1.0"

        self.cookie = None
        self.token = None
        self.fed_auth = None
        self.rt_fa = None

        self._proxies = proxies

    @staticmethod
    def prepare_security_token_request(**kwargs):
        """Construct the request body to acquire security token from STS endpoint."""
        request_data = SAMLAuth.SAML_TMPLT
        for k, v in kwargs.items():
            request_data = request_data.replace("[%s]" % k, v)
        return request_data

    @staticmethod
    def process_service_token_response(content):
        """Get service token response."""
        xml = ElementTree.fromstring(content)
        ns_prefixes = {
            "S": "{http://www.w3.org/2003/05/soap-envelope}",
            "psf": "{http://schemas.microsoft.com/Passport/SoapServices/SOAPFault}",
            "wst": "{http://schemas.xmlsoap.org/ws/2005/02/trust}",
            "wsse": "{http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd}",
        }

        if xml.find("{0}Body/{0}Fault".format(ns_prefixes["S"])) is not None:
            error = xml.find(
                "{0}Body/{0}Fault/{0}Detail/{1}error/{1}internalerror/{1}text".format(
                    ns_prefixes["S"], ns_prefixes["psf"]
                )
            )
            raise ValueError(
                "An error occurred while retrieving token: {0}".format(error.text)
            )

        token = xml.find(
            "{0}Body/{1}RequestSecurityTokenResponse/{1}RequestedSecurityToken/{2}BinarySecurityToken".format(
                ns_prefixes["S"], ns_prefixes["wst"], ns_prefixes["wsse"]
            )
        )
        return token.text

    def __call__(self, r):
        """Return authentication response."""
        if self.fed_auth is None or self.rt_fa is None:
            try:
                from urlparse import urlparse
            except ImportError:
                from urllib.parse import urlparse
            url = urlparse(self.url)
            auth_endpoint = url.scheme + "://" + url.hostname + self.login

            request_data = self.prepare_security_token_request(
                endpoint=auth_endpoint, username=self.username, password=self.password
            )

            response = requests.post(
                self.sts,
                data=request_data,
                headers={"Content-Type": Constants.HEADER_CONTENT_TYPE},
                timeout=self.timeout,
                proxies=self._proxies,
            )
            token = self.process_service_token_response(response.content)

            response = requests.post(
                auth_endpoint,
                data=token,
                timeout=self.timeout,
                proxies=self._proxies,
                headers={"Content-Type": Constants.HEADER_CONTENT_TYPE},
            )

            cookies_dict = requests.utils.dict_from_cookiejar(response.cookies)
            self.rt_fa = cookies_dict["rtFa"]
            self.fed_auth = cookies_dict["FedAuth"]

        self.cookie = "FedAuth=" + self.fed_auth + "; rtFa=" + self.rt_fa
        r.headers["Cookie"] = self.cookie
        r.headers["Accept"] = Constants.HEADER_ACCEPT
        return r


class OAuth(AuthBase):
    """OAuth access token provider.

    Warning:
        This is only dry draft. Never tested!
        Steps just followed according to the MS Azure docs.
        No errors handling.

    """

    AUTHORIZE = "https://login.microsoftonline.com/{tenant_id}/oauth2/authorize"
    GET_TOKEN = "https://login.microsoftonline.com/{tenant_id}/oauth2/token"

    def __init__(
        self, resource, client_id, client_secret, tenant_id="common", proxies=None, timeout=100
    ):
        """The OAuth class object initialization.

        Args:
            resource(str): connection url
            client_id(str): client id
            client_secret(str): client secret
            edge_point(str, optional): SharePoint url
            tenant_id(str, optional): tenant id
            proxies(dict, optional): connection proxy
            use_pg_gcp_proxy(bool, optional): use default PG proxy if 'proxies' not defined
        """
        self.resource = resource
        self.client_id = client_id
        self.__client_secret = client_secret
        self.tenant_id = tenant_id

        self.__token = None
        self.__refresh_token = None
        self.expires_on = None
        self.timeout = timeout

        self._proxies = proxies

    def _authorize(self):
        """Authorize with provided credentials."""
        url = OAuth.AUTHORIZE.format(tenant_id=self.tenant_id)
        headers = {
            "Accept": Constants.HEADER_ACCEPT,
            "Content-Type": Constants.HEADER_CONTENT_TYPE,
        }
        payload = {
            "client_id": self.client_id,
            "response_type": "code",
            "resource": self.resource,
        }
        r = requests.post(
            url, headers=headers, data=payload, timeout=self.timeout, proxies=self._proxies
        )

        return r.json()["code"]

    def _acquire_token(self, code=None, refresh=False):
        """Get token, refresh token and expiration date."""
        url = OAuth.GET_TOKEN.format(tenant_id=self.tenant_id)
        headers = {
            "Accept": Constants.HEADER_ACCEPT,
            "Content-Type": Constants.HEADER_CONTENT_TYPE,
        }
        payload = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "code": code,
            "resource": self.resource,
            "client_secret": self.__client_secret,
        }

        if refresh:
            payload["refresh_token"] = self.__refresh_token
            payload["grand_type"] = "refresh_token"
            del payload["code"]

        r = requests.post(
            url, headers=headers, data=payload, timeout=self.timeout, proxies=self._proxies
        )
        response = r.json()

        self.__token = response["access_token"]
        self.__refresh_token = response["refresh_token"]
        self.expires_on = datetime.utcfromtimestamp(int(response["expires_on"]))

        return self.__token, self.__refresh_token, self.expires_on

    def __call__(self, r):
        """Set token and headers."""
        if not self.__token:
            auth_code = self._authorize()
            self._acquire_token(code=auth_code)

        if self.expires_on < datetime.utcnow():
            self._acquire_token(refresh=True)

        r.headers["Authorization: Bearer"] = self.__token
        r.headers["Accept"] = Constants.HEADER_ACCEPT
        return r
