import logging
from datetime import datetime
from datetime import date
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
from pyspark.sql.functions import *

from ..sharepoint_reader import SharepointIngestion
logging.getLogger("py4j").setLevel(logging.ERROR)

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)

class AdvancedLogHandler:
    """
    The AdvancedLogHandler class is designed to log actions in scripts.

    Attributes of the class:
        - logging_root_folder (str): root folder for logs
        - log_post_sp_name (str): name of the SharePoint site for sending logs
        - log_post_root_folder (str): root folder for sending logs to SharePoint
        - username (str): username of the SharePoint user
        - password (str): password of the SharePoint user
        - site_type (str): sharepoint\onedrive site type

    Class methods (main):
        - log_point(self, log_point_name, point_type, point_sub_type, status, description, context):
         method for writing a log point to a file and adding it to the log list
        - start_logger(self): method for logging start to file and adding log point "SCRIPT_INITIAL"
        - end_logger(self): A property that completes logging and uploads a log file to a SharePoint site,
         writes logs information to delta table.

    You can find more details with the help(< method name >) command

    Example of use:
        log_handler = AdvancedLogHandler(
            logging_root_folder="/logs",
            log_post_sp_name="my_sharepoint",
            log_post_root_folder="/logs",
            username="user",
            password="password",
            site_type="sharepoint"
        )

        log_handler.start_logger

        log_handler.log_point(
            log_point_name="EXAMPLE_POINT",
            point_type="INFO",
            point_sub_type="EXAMPLE",
            status=True,
            description="Example description",
            context="Example context"
        )

        log_handler.end_logger

    """

    def __init__(
            self,
            logging_root_folder: str,
            log_post_sp_name: str,
            log_post_root_folder: str,
            username: str,
            password: str,
            site_type: str,
    ):
        self.logging_root_folder = logging_root_folder
        self.log_post_root_folder = log_post_root_folder
        self.log_post_sp_name = log_post_sp_name

        self.logging_file_subfolder = f"{date.today().year}/{date.today().strftime('%Y-%m')}/{date.today()}/{self.get_notebook_name}"

        self.txt_log_post_folder = (
            f"{log_post_root_folder}/{self.logging_file_subfolder}"
        )
        self.logging_path = f"/dbfs{logging_root_folder}/{self.logging_file_subfolder}/"

        self.logging_filename = f"log_{self.get_notebook_name}_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.txt"

        self.username = username
        self.password = password
        self.site_type = site_type

        self.logs_handler = []

        self.check_folder_exist(self.logging_path)
        logging.basicConfig(
            filename=self.logging_path + self.logging_filename,
            filemode="w",
            format="[%(asctime)s] [%(name)s] > %(message)s",
            level=logging.INFO,
            encoding="UTF-8",
            force=True,
        )
        self.log_ = logging.getLogger(f"core.{self.get_notebook_name}")

    @property
    def get_notebook_name(self) -> str:
        """
        A property method that returns the name of the current notebook.

        Returns:
            str: The name of the current notebook.
        """

        return (
            dbutils.notebook.entry_point.getDbutils()
            .notebook()
            .getContext()
            .notebookPath()
            .get()
            .split("/")[-1]
        )

    def check_folder_exist(self, path: str) -> bool:
        """
        A method that checks if a folder exists at the given path and creates it if it doesn't.

        Args:
            path (str): The path to the folder to check/create.
        Returns:
            bool: True if the folder already exists or was successfully created, False otherwise.
        """

        if "/dbfs" in path:
            path = path.replace("/dbfs", "")
        return dbutils.fs.mkdirs(path)

    def log_point(
            self,
            log_point_name: str,
            point_type: str,
            point_sub_type: str,
            status: bool,
            description: str,
            context: str,
    ):
        """
        A method that logs information about a certain point and appends it to a list of logs.

        Args:
            log_point_name (str): The name of the point to log.
            point_type (str): The type of the point (e.g. "data", "model", "evaluation").
            point_sub_type (str): The sub-type of the point (e.g. "preprocessed", "trained").
            status (bool): The status of the point (True for success, False for failure).
            description (str): A description of the point or test result.
            context (str): Additional context information about the point or
            smth that must be logged just in file.

        Returns:
            None.
        """

        self.log_.info(
            f"[{point_type}]: {log_point_name} --> result [{status}]: {description} \n{context}"
        )
        self.logs_handler.append(
            (
                self.get_notebook_name,
                datetime.now(),
                log_point_name,
                point_type,
                point_sub_type,
                status,
                description,
            )
        )
        print(f"point < {log_point_name} > was created")

    @property
    def start_logger(self):
        """
        A property method that initializes logging and logs information about the script initialization.

        Returns:
            None.
        """
        self.log_.info(
            f"< LOGGING INITIALIZATION. INIT DATETIME: {datetime.now()}. LOGGING SCRIPT: {self.get_notebook_name} >"
        )
        self.log_point(
            log_point_name="SCRIPT_INITIAL",
            point_type="INFO",
            point_sub_type="INITIAL INFO",
            status=True,
            description="STANDART: Script was initiated.",
            context="",
        )

    @property
    def collect_delta_log(self) -> DataFrame:
        """
        A property method that returns a DataFrame containing delta logs collected by the logs_handler.

        Returns:
            A DataFrame containing delta logs with columns "notebook_name", "log_time",
            "log_point_name", "point_type", "point_sub_type", "status", and "description".
        """

        return spark.createDataFrame(
            self.logs_handler,
            [
                "notebook_name",
                "log_time",
                "log_point_name",
                "point_type",
                "point_sub_type",
                "status",
                "description",
            ],
        )

    def adding_link_to_delta_log(self, df: DataFrame, link: str) -> DataFrame:
        """
        A method that adds a link to the delta log DataFrame and creates a
        time period partition column based on the last day of the log_time column.

        Args:
            df (DataFrame): A DataFrame containing delta logs.
            link (str): A string representing a link to be added to the DataFrame.

        Returns:
            A new DataFrame with an additional column "txt_log_link" containing the provided link and
            a column "time_period_partition" based on the last day of the "log_time" column.
        """

        return df.withColumn("txt_log_link", lit(link)).withColumn(
            "time_period_partition", last_day(col("log_time"))
        )

    @property
    def post_txt_on_sp(self):
        """
        A property that uploads a log file to a SharePoint site and returns a link to the uploaded file.

        Returns:
            A string representing a link to the uploaded log file on the SharePoint site.
        """

        loc_session = SharepointIngestion(
            username=self.username,
            password=self.password,
            site_type=self.site_type,
        )

        loc_session.upload_files_from_blob(
            sharepoint_name=self.log_post_sp_name,
            needed_folder=self.txt_log_post_folder,
            file_name=self.logging_filename,
            blob_path=self.logging_path,
        )
        return f"{loc_session.site(sharepoint_name=self.log_post_sp_name)}/{self.txt_log_post_folder}/{self.logging_filename}"

    @property
    def end_logger(self):
        """
        A property that completes logging and uploads a log file to a SharePoint site,
        writes logs information to delta table.

        Returns:
            None.
        """
        self.log_.info(
            f"< LOGGING COMPLETE. COMPLETE DATETIME: {datetime.now()}. LOGGING SCRIPT: {self.get_notebook_name} >"
        )
        self.log_point(
            log_point_name="SCRIPT_END",
            point_type="INFO",
            point_sub_type="END INFO",
            status=True,
            description="STANDART: Script was completed.",
            context="",
        )
        logging.shutdown()
        link = self.post_txt_on_sp
        self.adding_link_to_delta_log(self.collect_delta_log, link).write.save(
            f"{self.logging_root_folder}/delta_format_logs",
            format="delta",
            partitionBy="time_period_partition",
            mode="append",
        )
        print("logs successfully saved")
        return link
