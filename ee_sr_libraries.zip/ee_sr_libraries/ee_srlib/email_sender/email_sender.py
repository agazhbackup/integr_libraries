import requests
import base64
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
spark = SparkSession.getActiveSession()
dbutils = DBUtils(spark)

class EmailSender:

    def __init__(
        self,
        client_id: str = dbutils.secrets.get('lp14dv', 'EmailSender-Client-ID'),
        tenant_id: str = dbutils.secrets.get('lp14dv', 'EmailSender-Tenant-ID'),
        client_secret: str = dbutils.secrets.get('lp14dv', 'EmailSender-AppToken'),
    ) -> None:

        self.sender: str = "eedatahub.im@pg.com"
        self.client_id = client_id
        self.tenant_id = tenant_id
        self.client_secret = client_secret

        self.body = {"message": {"body": {}}}
        self.header = {}

    @staticmethod
    def encode_base64(attachment_path):
        with open(attachment_path, 'rb') as f:
            data = f.read()
        base64_encoded = base64.b64encode(data).decode('UTF-8')
        return base64_encoded

    @staticmethod
    def _check_main_args(recipient, subject, msg):
        if len(recipient) == 0:
            raise Exception('recipient is empty')
        if not (isinstance(recipient, str) or isinstance(recipient, list)):
            raise TypeError('recipient is not str or list')
        if isinstance(recipient, str):
            if "@" not in recipient:
                raise Exception('recipient is invalid, should be correct email')
            if " " in recipient:
                raise Exception("recipient is invalid, should be correct email. It is possible that several e-mails are transmitted in one line. The key character is (space).")
            if recipient.count("@") > 1:
                raise Exception("recipient is invalid, should be correct email. It is possible that several e-mails are transmitted in one line. The key character is (@).")
        if isinstance(recipient, list):
            for element in recipient:
                if not isinstance(element, str):
                    raise TypeError(f'one of recipients is not str: {element}')
                if "@" not in element:
                    raise Exception(f'one of recipients is invalid, should be correct email: {element}')
                if " " in element:
                    raise Exception(f"one of recipients is invalid, should be correct email. It is possible that several e-mails are transmitted in one line. The key character is (space) in: {element}.")
                if element.count("@") > 1:
                    raise Exception(f"recipient is invalid, should be correct email. It is possible that several e-mails are transmitted in one line. The key character is (@) in: {element}.")

        if subject is None:
            raise Exception('subject is empty')
        if not isinstance(subject, str):
            raise TypeError('subject is not str')
        if msg is None:
            raise Exception('msg is empty')
        if not isinstance(msg, str):
            raise TypeError('msg is not str')

    @staticmethod
    def _check_attachment_args(attachment_name, attachment, attachment_type):
        if attachment_name is None:
            raise Exception('attachment_name is empty')
        if not isinstance(attachment_name, str):
            raise TypeError('attachment_name is not str')
        if attachment is None:
            raise Exception('attachment is empty')
        if attachment_type is None:
            raise Exception('attachment_type is empty')
        if not isinstance(attachment_type, str):
            raise TypeError('attachment_type is not str')
        if attachment_type not in ['path', 'base64']:
            raise ValueError('attachment_type could be path or base64, received - ' + attachment_type)

    @staticmethod
    def _attachment_handler(body, attachment_name, attachment, attachment_type):
        if (attachment_name is not None) or (attachment is not None):
            EmailSender._check_attachment_args(attachment_name, attachment, attachment_type)
            body['message']['attachments'] = [
                {
                    "name": attachment_name,
                    "contentType": "text/plain"
                }
            ]
            if attachment_type == 'path':
                body['message']['attachments'][0]["@odata.type"] = '#microsoft.graph.fileAttachment'
                body['message']['attachments'][0]["contentBytes"] = EmailSender.encode_base64(attachment)
            elif attachment_type == 'base64':
                body['message']['attachments'][0]["@odata.type"] = '#microsoft.graph.fileAttachment'
                body['message']['attachments'][0]["contentBytes"] = attachment
            else:
                body['message']['attachments'][0]["@odata.type"] = '#microsoft.graph.referenceAttachment'
                body['message']['attachments'][0]["id"] = attachment
        return body
    
    @property
    def __auth(self) -> "requests.session":
        """
        Method for performing authontification in the API with the help of which messages are sent
        """
        s = requests.session()
        auth_url = (
            f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
        )
        auth_data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": "https://graph.microsoft.com/.default",
            "grant_type": "client_credentials",
        }
        token = s.post(auth_url, data=auth_data).json()["access_token"]
        self.header["Authorization"] = f"Bearer {token}"
        return s

    def send_email(self, recipient, subject, msg, attachment_name=None, attachment=None, attachment_type='path', content_type='Text', bbc_recipient=None):
        self._check_main_args(recipient, subject, msg)

        if isinstance(recipient, str):
            recipient_email = [{'EmailAddress': {'Address': recipient}}]
        elif isinstance(recipient, list):
            recipient_email = [{'EmailAddress': {'Address': address}} for address in recipient]
        else:
            raise TypeError('recipient is not str or list')

        body = {
            "message": {
                "subject": subject,
                "body": {
                    "contentType": content_type,
                    "content": msg
                },
                "toRecipients": recipient_email
            }
        }
        if bbc_recipient:
            self._check_main_args(bbc_recipient, subject, msg)
            if isinstance(bbc_recipient, str):
                bbc_recipient_email = [{'EmailAddress': {'Address': bbc_recipient}}]
            elif isinstance(bbc_recipient, list):
                bbc_recipient_email = [{'EmailAddress': {'Address': address}} for address in bbc_recipient]
            else:
                raise TypeError('recipient is not str or list')
            body["message"]["bccRecipients"] = bbc_recipient_email

        session = self.__auth
        body = self._attachment_handler(body, attachment_name, attachment, attachment_type)
        url_for_sending = f'https://graph.microsoft.com/v1.0/users/{self.sender}/sendMail'
        sending_result = session.post(url_for_sending, headers=self.header, json=body).text
        return sending_result