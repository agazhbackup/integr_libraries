from databricks.sdk.runtime import dbutils

class BlobPathValidating:

  """
  ############## Use Example ##############

  path = /mnt/.... #Path to main needed folder
  mask = ".jpg" # Files naming mask, should be like string
  blb_pth = BlobPathValidating(path, mask) # Making class object 
  paths_photo = blb_pth.get_needed_paths() # taking paths of all existing files with needed mask

  Output data type: SET of unique file paths
  """
  
  def __init__(self, path, file_mask):
    self.path = path
    self.file_mask = file_mask
    
  def __repr__(self):
    return 'This class is used to iterate within folders on a blob storage. It helps to get the paths to certain files in the blob.'
  
  @classmethod
  def get_dir_content(cls, path):
    dir_paths = dbutils.fs.ls(path)
    subdir_paths = [BlobPathValidating.get_dir_content(p.path) for p in dir_paths if p.isDir() and p.path != path]
    flat_subdir_paths = [p for subdir in subdir_paths for p in subdir]
    return list(map(lambda p: p.path, dir_paths)) + flat_subdir_paths
  
  def get_needed_paths(self): #main metod
    paths= BlobPathValidating.get_dir_content(self.path)
    paths = set([x for x in paths if x[-len(self.file_mask):] == self.file_mask])
    return paths

  def get_all_paths(self): #main metod
    paths= BlobPathValidating.get_dir_content(self.path)
    paths = set( paths )
    return paths