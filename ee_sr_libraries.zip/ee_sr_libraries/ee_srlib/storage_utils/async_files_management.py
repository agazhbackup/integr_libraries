from typing import Dict, List, Optional, Callable
import asyncio
from databricks.sdk.runtime import dbutils

class AsyncFileSystemHandler:
    """
    The class uses AsyncIO module to speed up work with dbfs operations: move files, copy files, delete files

    How to use:
    1) Create an instance:
    async_file_system = AsyncFileSystemHandler()
    2) await any method, which does not start with "_"
    await async_file_system.copy_files(source_destination_mapping)
    """

    async def _copy_or_move_files(self, file_paths: Dict[str, str], dbfs_function: Callable) -> List[asyncio.Task]:
        if not isinstance(file_paths, dict):
            raise ValueError('Pass file_paths in dict format, where key is source path and value is destination path')

        if dbfs_function not in (dbutils.fs.cp, dbutils.fs.mv):
            raise NotImplementedError('Method implements only dbutils.fs.cp, dbutils.fs.mv')

        tasks = []

        for source_path, destination in file_paths.items():
            coroutine = asyncio.to_thread(dbfs_function, source_path, destination, True)
            task = asyncio.create_task(coroutine)
            tasks.append(task)

        executed_tasks = await self._execute_tasks(tasks)
        return executed_tasks

    async def move_files(self, file_paths: Dict[str, str]) -> List[asyncio.Task]:
        executed_tasks = await self._copy_or_move_files(file_paths, dbutils.fs.mv)
        return executed_tasks

    async def copy_files(self, file_paths: Dict[str, str]) -> List[asyncio.Task]:
        executed_tasks = await self._copy_or_move_files(file_paths, dbutils.fs.cp)
        return executed_tasks

    async def delete_files(self, file_paths: List[str]) -> List[asyncio.Task]:
        if not isinstance(file_paths, list):
            raise ValueError('Pass file_paths in list format')

        tasks = []

        for path in file_paths:
            coroutine = asyncio.to_thread(dbutils.fs.rm, path, True)
            task = asyncio.create_task(coroutine)
            tasks.append(task)

        executed_tasks = await self._execute_tasks(tasks)
        return executed_tasks

    def _check_errors(self, finished_tasks: List[asyncio.Task]) -> List[str]:
        errors = []

        for task in finished_tasks:
            err = task.exception()
            if err:
                errors.append(err)

        return errors

    async def _execute_tasks(self, tasks: List[asyncio.Task]) -> List[asyncio.Task]:
        done, pending = await asyncio.wait(tasks)
        if pending:
            print('PENDING TASKS', pending)
            raise TimeoutError

        errors = self._check_errors(done)
        if errors:
            for err in errors:
                print(str(err), '\n')
            raise ValueError
        return done
