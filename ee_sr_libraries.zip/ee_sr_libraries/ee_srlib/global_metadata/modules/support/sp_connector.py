from ee_srlib.global_metadata.modules.support.errors import SharePointDownloadingError
from ee_srlib.global_metadata.modules.config import *
from requests.auth import AuthBase
from xml.etree import ElementTree
from urllib.parse import urlparse
from textwrap import dedent
from io import BytesIO
import requests
import json
import re

from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


class Constants_MH:
    """Store constant values."""

    HEADER_ACCEPT = "application/json"
    HEADER_CONTENT_TYPE = "application/x-www-form-urlencoded"
    MICROSOFT_STS_URL = "https://login.microsoftonline.com/extSTS.srf"


class SAMLAuth_MH(AuthBase):
    """SAML authorization class."""

    SAML_TMPLT = dedent(
        """
    <s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing"
    xmlns:u="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
        <s:Header>
            <a:Action s:mustUnderstand="1">http://schemas.xmlsoap.org/ws/2005/02/trust/RST/Issue</a:Action>
            <a:ReplyTo>
            <a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address>
            </a:ReplyTo>
            <a:To s:mustUnderstand="1">https://login.microsoftonline.com/extSTS.srf</a:To>
            <o:Security s:mustUnderstand="1"
            xmlns:o="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
            <o:UsernameToken>
                <o:Username>[username]</o:Username>
                <o:Password>[password]</o:Password>
            </o:UsernameToken>
            </o:Security>
        </s:Header>
        <s:Body>
            <t:RequestSecurityToken xmlns:t="http://schemas.xmlsoap.org/ws/2005/02/trust">
            <wsp:AppliesTo xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy">
                <a:EndpointReference>
                <a:Address>[endpoint]</a:Address>
                </a:EndpointReference>
            </wsp:AppliesTo>
            <wsp:PolicyReference xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy"
            URI="MBI"></wsp:PolicyReference>
            <t:KeyType>http://schemas.xmlsoap.org/ws/2005/05/identity/NoProofKey</t:KeyType>
            <t:RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</t:RequestType>
            <t:TokenType>urn:oasis:names:tc:SAML:1.0:assertion</t:TokenType>
            </t:RequestSecurityToken>
        </s:Body>
    </s:Envelope>"""
    )

    def __init__(self, url, username, password, timeout=100):
        """The SAMLAuth_MH class object initialization.

        Args:
            url(str): connection url
            username(str): user email address
            password(str): user password
            proxies(dict, optional): connection proxy
        """
        self.url = url
        self.username = username
        self.password = password
        self.timeout = timeout

        # External Security Token Service for SPO
        self.sts = Constants_MH.MICROSOFT_STS_URL
        # Sign in page url
        self.login = "/_forms/default.aspx?wa=wsignin1.0"

        self.cookie = None
        self.token = None
        self.rtFa = None
        self.FedAuth = None

    @staticmethod
    def prepare_security_token_request(**kwargs):
        """Construct the request body to acquire security token from STS endpoint."""
        request_data = SAMLAuth_MH.SAML_TMPLT
        for k, v in kwargs.items():
            request_data = request_data.replace("[%s]" % k, v)
        return request_data

    @staticmethod
    def process_service_token_response(content):
        """Get service token response."""
        xml = ElementTree.fromstring(content)
        ns_prefixes = {
            "S": "{http://www.w3.org/2003/05/soap-envelope}",
            "psf": "{http://schemas.microsoft.com/Passport/SoapServices/SOAPFault}",
            "wst": "{http://schemas.xmlsoap.org/ws/2005/02/trust}",
            "wsse": "{http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd}",
        }

        if xml.find("{0}Body/{0}Fault".format(ns_prefixes["S"])) is not None:
            error = xml.find(
                "{0}Body/{0}Fault/{0}Detail/{1}error/{1}internalerror/{1}text".format(
                    ns_prefixes["S"], ns_prefixes["psf"]
                )
            )
            raise ValueError(
                "An error occurred while retrieving token: {0}".format(error.text)
            )

        token = xml.find(
            "{0}Body/{1}RequestSecurityTokenResponse/{1}RequestedSecurityToken/{2}BinarySecurityToken".format(
                ns_prefixes["S"], ns_prefixes["wst"], ns_prefixes["wsse"]
            )
        )
        return token.text

    def __call__(self, r):
        """Return authentication response."""
        url = urlparse(self.url)
        auth_endpoint = url.scheme + "://" + url.hostname + self.login

        request_data = self.prepare_security_token_request(
            endpoint=auth_endpoint, username=self.username, password=self.password
        )

        response = requests.post(
            self.sts,
            data=request_data,
            headers={"Content-Type": Constants_MH.HEADER_CONTENT_TYPE},
            timeout=self.timeout,
        )
        token = self.process_service_token_response(response.content)

        response = requests.post(
            auth_endpoint,
            data=token,
            timeout=self.timeout,
            headers={"Content-Type": Constants_MH.HEADER_CONTENT_TYPE},
        )

        cookies_dict = requests.utils.dict_from_cookiejar(response.cookies)
        self.rtFa = cookies_dict["rtFa"]
        self.FedAuth = cookies_dict["FedAuth"]

        self.cookie = "FedAuth=" + self.FedAuth + "; rtFa=" + self.rtFa
        r.headers["Cookie"] = self.cookie
        r.headers["Accept"] = Constants_MH.HEADER_ACCEPT
        return r


class SharePointBaseConnector_MH:
    def __init__(self, username, password, sitename, site_type = "sharepoint"):
        self.username = username
        self.password = password
        self.sitename = sitename

        self.sp_conf = {
            "sharepoint": {
                "url" : "https://pgone.sharepoint.com/",
                "type" : "sites"
            },
            "onedrive" : {
                "url" : "https://pgone-my.sharepoint.com/",
                "type" : "personal"
            }
        }

        self.url = self.sp_conf[site_type]["url"]
        self.sitetype = self.sp_conf[site_type]["type"]

    @property
    def session(self) -> requests.sessions.Session:
        s = requests.Session()
        s.auth = SAMLAuth_MH(
            f"{self.url}/{self.sitetype}/{self.sitename}", self.username, self.password
        )
        return s

    def get_digest(self) -> str:
        """Needed to allow operations such as delete."""
        return self.session.post(
            f"{self.url}/{self.sitetype}/{self.sitename}/_api/contextinfo"
        ).json()["FormDigestValue"]

    def get_json_file(self, folder: str, filename: str) -> dict:
        api_url = f"{self.url}/{self.sitetype}/{self.sitename}/_api/web/GetFolderByServerRelativeUrl('/{self.sitetype}/{self.sitename}/{folder}')/Files('{filename}')/$value"
        return self.session.get(api_url, stream=True).json()

    def post_json_file(self, dict_info: dict, folder: str, filename: str) -> dict:
        api_url = f"{self.url}/{self.sitetype}/{self.sitename}/_api/web/GetFolderByServerRelativeUrl('/{self.sitetype}/{self.sitename}/{folder}')/Files/add(url='{filename}', overwrite=true)"
        json_bytes = bytes(json.dumps(dict_info), "utf-8")
        headers = {
            "Accept": "application/json; odata=nometadata",
            "X-RequestDigest": self.get_digest(),
        }
        return self.session.post(api_url, data=json_bytes, headers=headers)
    
    def post_file(self, bytes_buffer: bytes, folder: str, filename: str) -> dict:
        api_url = f"{self.url}/{self.sitetype}/{self.sitename}/_api/web/GetFolderByServerRelativeUrl('/{self.sitetype}/{self.sitename}/{folder}')/Files/add(url='{filename}', overwrite=true)"
        headers = {
            "Accept": "application/json; odata=nometadata",
            "X-RequestDigest": self.get_digest(),
        }
        self.creating_folder(self.sitename, folder)
        return self.session.post(api_url, data=bytes_buffer, headers=headers)

    def get_sub_folders_list(self, folder: str) -> list:
        api_url = f"{self.url}/{self.sitetype}/{self.sitename}/_api/web/GetFolderByServerRelativeUrl('/{self.sitetype}/{self.sitename}/{folder}')/Folders"
        sub_folders_list = self.session.get(api_url).json()["value"]
        return [_["Name"] for _ in sub_folders_list]

    def get_files_list_in_folder(self, folder: str) -> list:
        api_files_url = f"{self.url}/{self.sitetype}/{self.sitename}/_api/web/GetFolderByServerRelativeUrl('/{self.sitetype}/{self.sitename}/{folder}')/Files"
        files = self.session.get(api_files_url).json()["value"]
        return [_["Name"] for _ in files]

    def save_current_file(self, folder: str, filename: str, blob_path: str) -> str:
        api_url = f"{self.url}/{self.sitetype}/{self.sitename}/_api/web/GetFolderByServerRelativeUrl('/{self.sitetype}/{self.sitename}/{folder}')/Files('{filename}')/$value"
        r = self.session.get(api_url, stream=True)
        if r.status_code == 200:
            with open("/dbfs" + blob_path + filename, "wb") as f:
                f.write(r.content)

            return f"File saved as {filename} in folder {blob_path}"
        else:
            raise SharePointDownloadingError(
                "This file cannot be downloaded, please make sure that the file information in the metadata is correct."
            )

    def get_files_list_in_all_sub_folder(self, folder: str) -> dict:

        files_list = dict()

        files_collected = self.get_files_list_in_folder(f"{folder}")
        if files_collected:
            files_list[f"{folder}"] = files_collected

        for sub_folder in self.get_sub_folders_list(folder):
            files_list.update(
                self.get_files_list_in_all_sub_folder(f"{folder}/{sub_folder}")
            )

        return files_list

    def save_several_files(self, folder: str, blob_path: str, r_pattern: str) -> list:
        files_collected = self.get_files_list_in_all_sub_folder(folder)
        return [
            self.save_current_file(cf, _, blob_path)
            for cf, files in files_collected.items()
            for _ in files
            if bool(re.match(rf"{r_pattern}", _))
        ]

    def download_files_to_blob(
        self, folder: str, filename_or_mask: str, blob_path: str, is_folder: bool
    ) -> list:
        dbutils.fs.mkdirs(blob_path)
        if is_folder:
            result = self.save_several_files(folder, blob_path, filename_or_mask)
        else:
            result = [self.save_current_file(folder, filename_or_mask, blob_path)]
        return result
    
    def __cheking_folder_existing(
        self, sitename: str, folder: str
    ) -> bool:

        """
        This function is designed to check the presence of a folder in Sharepoint.

        Args:
          sitename [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sitetype/sitename/ >
          folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
        Returns:
          folder_ex [bool] : The folder presence marker: True - present, False - absent.
        """
        _folder = (
            self.session.get(
                f"{self.url}/{self.sitetype}/{self.sitename}/_api/web/GetFolderByServerRelativeUrl('/{self.sitetype}/{sitename}/{folder}')"
            )
            .json()
        )
        folder_ex = True
        try:  # Checking for a folder on sharepoint
            _folder["Name"]
        except Exception:
            folder_ex = False
        return folder_ex
    
    def creating_folder(self, sitename: str, folder: str) -> None:
        """
        This function creates a folder in Sharepoint if it does not exist.
        Attention, cannot create a pack in a folder that has not been created yet.

        Args:
          sitename [str] : The name of the Sharepoint site. You can get it from the URL. < https://pgone.sharepoint.com/sitetype/sitename/ >
          folder [str] : Path to the folder in Sharepoint. Please don't forget about root folder < RootFolder/Subfolder_1/Subfolder_2 >
        """

        headers = {
            "Accept": "application/json; odata=nometadata",
            "X-RequestDigest": self.get_digest(),
        }

        if not self.__cheking_folder_existing(sitename, folder):
            folder_split = folder.split("/")

            for ix in range(1, len(folder_split)):
                root_folder = "/".join(folder_split[: ix + 1])
                is_exist = self.__cheking_folder_existing(sitename, root_folder)
                if not is_exist:
                    self.session.post(f"{self.url}/{self.sitetype}/{self.sitename}/_api/web/Folders/add('{root_folder}')", headers=headers)

    