from pyspark.sql.types import *
import numpy as np
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()

def equivalent_type(f):
    if f == 'datetime64[ns]': return TimestampType()
    elif f == 'int64': return LongType()
    elif f == 'int32': return IntegerType()
    elif f == 'float64': return DoubleType()
    else: return StringType()

def define_structure(string, format_type):
    try: typo = equivalent_type(format_type)
    except: typo = StringType()
    return StructField(string, typo)

# Given pandas dataframe, it will return a spark's dataframe.
def pandas_to_spark(pandas_df, replace_none=True):
    columns = list(pandas_df.columns)
    types = list(pandas_df.dtypes)
    struct_list = []
    for column, typo in zip(columns, types): 
      struct_list.append(define_structure(column, typo))
    p_schema = StructType(struct_list)
    if replace_none:
        return spark.createDataFrame(pandas_df, p_schema).replace(np.nan, None)
    else:
        return spark.createDataFrame(pandas_df, p_schema)