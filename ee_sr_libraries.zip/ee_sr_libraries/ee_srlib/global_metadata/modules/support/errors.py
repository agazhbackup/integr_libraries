class MetadataConnectionError(Exception):
  "Raises an error when it is impossible to connect to the metadata in one of the available ways"

class SharePointDownloadingError(Exception):
  "Raises an error when it is impossible to download file from sharepoint correctly"

class SharePointUploadingError(Exception):
  "Raises an error when it is impossible to upload file to sharepoint correctly"

class FileFormatError(Exception):
  "Raises an error when file format is not intended to be handled by metadata"

class UserInputError(Exception):

  "Raises an error when the user passed incorrect parameters to interact with the metadata"

class InvalidArgument(ValueError):
  "Raises an error when invalid argument value was provided"
