
from pyspark.sql.window import Window
from pyspark.sql import DataFrame
from datetime import datetime
from pyspark.sql.types import (
    StructField,
    StructType,
    StringType,
    TimestampType,
)

import pyspark.sql.functions as f
import hashlib
import json

from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


class EnvInfoExtractor:

    """
    This class is used to get the parameters of the current neighbourhood and helps logging to save the necessary information

    When an object of a class is created, all available information is taken from the environment and stored in memory

    Properties:
        get_env_key - uri current databricks env (adb-1000000000000000.0.azuredatabricks.net)
        get_notebook_path - current notebook full path (/Repos/.../.../.../current_notebbok)
        get_user_info - user email (user@pg.com)
        get_org_id - workspase id (1000000000000000)
        get_notebook_id - unique notebook ID 
        get_current_timestamp - current date-time
        get_job_run_url - URL on job run or < URL not available > string if started manually
        get_notebook_link - URL for current notebook

    """

    def __init__(self):
        self.current_env_params = json.loads(
            dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()
        )
        self.current_env_params["env_key_setted"] = spark.conf.get("spark.databricks.workspaceUrl")


    @property
    def get_env_key(self) -> str:
        """ 
        Function for getting uri current databricks env (adb-1000000000000000.0.azuredatabricks.net)
        """
        return self.current_env_params["env_key_setted"]

    @property
    def get_notebook_path(self) -> str:
        """
        Function for getting current notebook full path (/Repos/.../.../.../current_notebbok)
        """
        return self.current_env_params["extraContext"]["notebook_path"]

    @property
    def get_user_info(self) -> str:
        """
        Function for getting user email (user@pg.com)
        """
        return self.current_env_params["tags"]["user"]

    @property
    def get_org_id(self) -> str:
        """
        Function for getting workspase id (1000000000000000)
        """
        return self.current_env_params["tags"]["orgId"]

    @property
    def get_notebook_id(self) -> str:
        """
        Function for getting unique notebook ID
        """
        return self.current_env_params["extraContext"]["notebook_id"]

    @property
    def get_current_timestamp(self) -> "datetime":
        """
        Function for getting current date-time
        """
        return datetime.now()

    @property
    def get_job_run_url(self) -> str:
        """
        Function for getting URL on job run or < URL not available > string if started manually
        """
        try:
            job_id = self.current_env_params["tags"]["jobId"]
            id_in_job = self.current_env_params["tags"]["idInJob"]
            workspace_url = self.get_env_key
            org_id = self.get_org_id
            url = f"https://{workspace_url}/?o={org_id}#job/{job_id}/run/{id_in_job}"

        except KeyError:
            url = "URL not available"

        return url

    @property
    def get_notebook_link(self) -> str:
        """
        Function for getting URL for current notebook
        """
        return f"https://{self.get_env_key}/?o={self.get_org_id}#notebook/{self.get_notebook_id}"


class MetadataTechLogger(EnvInfoExtractor):

    """
    A class with methods for logging user actions with information about a specific execution session

    Class object Args:
        log_colletion_path[str]: path where all logs will be collected

    Methods:
        extract_log_info - Method for getting needed params from session
        set_log_point - Method for putting information about action in temporary log collection (log_frame[list])
        action_logging - Decorator for performing logging manipulations on the function to be executed
        collect_dataframe_log - Function that converts the collected log into a spark dataframe
        exit_from_notebook - Function that saves all collected log to a table
    """

    def __init__(self, log_colletion_path: str):

        super().__init__()

        self.log_frame = []
        self.log_colletion_path = log_colletion_path


        self.notebook_run_key = hashlib.md5(
            f"{self.get_notebook_link}_{self.get_current_timestamp}".encode("UTF-8")
        ).hexdigest()

        self.log_schema = StructType(
            [
                StructField("metadata_code", StringType(), False),
                StructField("func_name", StringType(), False),
                StructField("log_timestamp", TimestampType(), False),
                StructField("user", StringType(), False),
                StructField("databricks_env_key", StringType(), False),
                StructField("notebook_path", StringType(), False),
                StructField("notebook_link", StringType(), False),
                StructField("notebook_run_key", StringType(), False),
                StructField("job_link", StringType(), False),
                StructField("run_type", StringType(), False),
            ]
        )


    @property
    def extract_log_info(self) -> tuple:
        """
        Method for getting needed params from session.
        This method accesses the parent class object and takes the environment variables required for logging.

        Returns:
            [tuple]: A set of variables derived from the current environment
        """
        return (
            self.get_current_timestamp,
            self.get_user_info,
            self.get_env_key,
            self.get_notebook_path,
            self.get_notebook_link,
        )

    def set_log_point(self, metadata_code: str, func_name: str) -> None:
        
        """
        Method for putting information about action in temporary log collection (log_frame[list])

        Args:
            metadata_code[str]: Unique data code from metadata (similar to PartitionKey)
            func_name[str]: String representation of the function to be performed
        """

        job_link = self.get_job_run_url
        run_type = "job" if "http" in job_link else "manual"
        extracted_log_info = self.extract_log_info

        self.log_frame.append(
            [
                metadata_code,
                func_name,
                *extracted_log_info,
                self.notebook_run_key,
                job_link,
                run_type,
            ]
        )

    def action_logging(self, func):
        """
        Decorator for performing logging manipulations on the function to be executed
        Execution Logic:
            The function is executed first
            Then the metadata code is extracted from the parameters passed to the function
            After that, the execution of the function is logged
            Then the result of the executed function is returned
        """
        def wrapper(*args, **kwargs):

            original_result = func(*args, **kwargs)

            called_code = (
                args[1]
                if "metadata_code" not in kwargs.keys()
                else kwargs["metadata_code"]
            )

            func_name = func.__name__

            self.set_log_point(called_code, func_name)

            return original_result

        return wrapper

    @property
    def collect_dataframe_log(self) -> DataFrame:
        """
        Function that converts the collected log into a spark dataframe

        Returns:
            [spark.DataFrame]: All logged actions in table view
        """
        return spark.createDataFrame(self.log_frame, self.log_schema)

    def exit_from_notebook(self, exit_result):
        """
        An output method that is required to save the log correctly.
        This method should be called when the code operation ends. 
        It collects the latest action information for each data code.
        
        Args:
            exit_result[Any]: The result with which the script should terminate
        Returns:
            [Any]: The result with which the script should terminate
        """
        log_collected = self.collect_dataframe_log
        initial_cols = log_collected.columns
        log_collected = log_collected.withColumn(
            "last_timestamp",
            f.max(f.col("log_timestamp")).over(
                Window.partitionBy("metadata_code", "func_name")
            ),
        )
        log_collected = log_collected.filter(
            f.col("log_timestamp") == f.col("last_timestamp")
        ).select(initial_cols)
       
        log_collected.write.save(self.log_colletion_path , format="avro", mode="append")
        return dbutils.notebook.exit(exit_result)
