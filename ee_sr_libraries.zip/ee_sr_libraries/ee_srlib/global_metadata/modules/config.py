from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)

# DEVS emails
DEVS_EMAILS_LIST = ["motern.r@pg.com", "berestovoy.dn@pg.com", "magomedov.r@pg.com"]

# PATHS
LOG_COLLECTION_PATH = "/mnt/blob/sdl/sdl-logs/metadata_handler"
SHARED_DATA_DQ_LOG_PATH = "/mnt/blob/sdl/sdl-logs/shared_data_dq_checks"


# CREDENTIALS
# Azure Tables
TABLES_API_WEB_URI = "table.core.windows.net"
TABLES_SAS_KEY_READ = dbutils.secrets.get(scope='lp14dv', key='sdl-storage-tables-read-sas')
TABLES_SAS_KEY_WRITE = dbutils.secrets.get(scope='lp14dv', key='sdl-storage-tables-write-sas')
STORAGE_ACCOUNT = "blobcdhlaunchpadeu14dv"
METADATA_CORE_TABLE_NAME = "EEMetadataRegistry"
METADATA_SCHEMA_REGISTRY_NAME = "EESchemaRegistry"

# Sharepoint
SP_USERNAME = "eehubingestion.im@pg.com"
SP_PASSWORD = dbutils.secrets.get(scope="lp14dv", key="eehubingestion")
SP_URL = "https://pgone.sharepoint.com/"
SP_SITE = "EEOperations2"


# Email Sender
ES_CLIENT_ID = dbutils.secrets.get("lp14dv", "EmailSender-Client-ID")
ES_TENANT_ID = dbutils.secrets.get("lp14dv", "EmailSender-Tenant-ID")
ES_CLIENT_SECRET = dbutils.secrets.get("lp14dv", "EmailSender-AppToken")

# SnapShots params
SP_SH_PATH = "Shared Documents/EE Local Projects/Global Metadata"
BLOB_SH_PATH = "/mnt/blob/sdl/backups/GlobalMetadata/snapshots/"
SH_FILENAME = "global_metadata_snapshot.json"
DELTA_SH_PATH = f"{BLOB_SH_PATH}delta_snapshot"
DELTA_SH_TABLE_NAME = "global_metadata.metadata_snapshot"

DELTA_SCHEMA_SH_PATH = f"{BLOB_SH_PATH}delta_schema_snapshot"
DELTA_SCHEMA_SH_TABLE_NAME = "global_metadata.data_schema_snapshot"

# Input properties dict
METADATA_FIELDS_PROPERTIES = {
    "PartitionKey": {
        "mandatory": True,
         "pattern": "^EE$", 
         "custom_error_message": "The default field should be 'EE'"},
    "RowKey": {
        "mandatory": True, 
        "pattern": "^[a-z]+(_[a-z]+)*$", 
        "custom_error_message": "The default metadata code should only contain lower case letters and underscores. Example: 'this_is_a_code'"},
    "type": {
        "mandatory": True, 
        "list": ["master", "fact", "lookup", "meta"], 
        "custom_error_message": "The default type should be either 'master', 'fact', 'lookup' or 'meta'"},
    "is_raw": {
        "mandatory": True, 
        "list": ["True", "False", True, False], 
        "custom_error_message": "The default type should be either True or False"},
    "is_shared": {
        "mandatory": True, 
        "list": ["True", "False", True, False], 
        "custom_error_message": "The default type should be either True or False"},
    "iaf_data_type": {
        "mandatory": True, 
        "list": [
            "Calendar of Events",
            "Financial Master Data",
            "Customer / Distributor / Wholesaler",
            "Information Technology (IT)",
            "Shipment",
            "Material Goods",
            "Store",
            "Distributor Sales & Supply Chain",
            "Customer Commercial Agreement",
            "Customer Sales & Supply Chain (POS)",
            "Trade Panel",
            "Management Reporting",
            "Digital Commerce",
            "Go to Market",
            "Sales Management",
            "Price",
            "Supply Chain"],
        "custom_error_message": "IAF data type should be among the available list options"},
    "data_classification": {
        "mandatory": True,
        "list": [
            "Highly Restricted",
            "Business Use"],
        "custom_error_message": "The data classification should be either 'Business Use' or 'Highly Restricted'"},
    "application_id": {
        "mandatory": True, 
        "pattern": "[EE]+\d{1,4}", 
        "custom_error_message": "The Application ID should start with 'EE' followed by 1-4 digits. Example: 'EE123'" },
    "owners": {
        "mandatory": True,
        "pattern": "^\[\s*'([a-zA-Z0-9_.+-]+@pg\.com)'\s*(,\s*'([a-zA-Z0-9_.+-]+@pg\.com)')*\s*\]$", 
        "custom_error_message": "The owners field should resemble a list of strings format with full emails of the code owners. The string should use single quotes ONLY. Example: ['magomedov.r@pg.com']" },
    "source_lp_id": {
        "mandatory": True,
        "list": [
            "lp-11dv",
            "lp-13dv",
            "lp-13ut",
            "lp-14dv",
            "lp-17dv",
            "lp-18dv",
            "lp-23ut",
            "lp-23dv",
            "lp-11prod",
            "lp-13prod",
            "lp-17prod",
            "lp-18prod",
            "lp-23prod"], 
            "custom_error_message": "The launchpad should be among the list of the existing resource groups in a format 'lp-NN[dv/ut/prod]. Examples: 'lp-14dv', 'lp-13prod'"},
    "refresh_schedule": {
        "mandatory": True,
        "pattern": "^(\*|\d+|\*\/\d+|\d+(-\d+)?|\?)(\s+(\*|\d+|\*\/\d+|\d+(-\d+)?|\?)){5}$",
        "custom_error_message": "The refresh schedule pattern should follow quartz CRON syntax. Example: * * * * * *"},
    "refresh_duration": {
        "mandatory": True, 
        "pattern": "\d+[h,m]", 
        "custom_error_message": "The refresh duration should be of format N[h/m] the amoung of minutes or hours for data to refresh. Example:'30m', '4h'"},
    "retention_policy": {
        "mandatory": True, 
        "pattern": "\d+[m]{2}", 
        "custom_error_message": "The retention policy should represent the number of months for data to be retained for. Example: '12mm', '36mm'"},
    "is_active": {
        "mandatory": True, 
        "list": ["True", "False", True, False], 
        "custom_error_message": "The default type should be either True or False"},
    "generic_source": {
        "mandatory": True, 
        "list": ["blob", "sharepoint", "onedrive"],
        "custom_error_message": "The default type should be either 'blob' or 'sharepoint' or 'onedrive'"},
    "blob_path": {
        "mandatory": True, 
        "condition": lambda x: (x.startswith("/mnt/")),# and x.endswith('/')),
        "custom_error_message": "Blob path should always start with '/mnt/'"},
    "file_name": {
        "mandatory": False,
        "customer_error_message": "File name should match the passed file format. Delta format does not support file naming."},
    "file_format": {
        "mandatory": True,
        "list": ["xlsx", "xlsm", "xlsb", "csv", "delta", "csv.gz", "parquet"],
        "custom_error_message": "File format should be among 'xlsx, 'xlsxm', 'xlsb', 'csv', 'delta', 'csv.gz', 'parquet'"},
    "sharepoint_path": {
        "mandatory": False,
        "condition": (lambda x: not x.startswith("/") and not x.endswith("/")),
        "custom_error_message": "Sharepoint path should not start or end with '/'."},
    "sharepoint_name": {
        "mandatory": False, 
        "condition": (lambda x: " " not in x),
        "custom_error_message": "Sharepoint name should not contain space characters. It is recommended to copy the sharepoin name from the URL."},
    "sheet_name": {
        "mandatory": False,
        "condition": (
            lambda x: (len(x) < 32)
            and (not any(i in ["?", "\\", "/", "*", "[", "]"] for i in x))
            and (x != "")
            ),
            "custom_error_message": "Sheet name should not be empty or longer than 31 characters or contain the following characters: ?/\\*[]"},
    "dbr_table_name": {
        "mandatory": False, 
        "pattern": "^[a-z0-9_]+\.[a-z0-9_]+$",
        "custom_error_message": "Database and table name should be separated by the '.' and contain only alpha-numeric characters in lower case and underscores. Example: 'database.table_name'"},
    "description": {
        "mandatory": True, 
        "pattern": "^[a-z0-9].{10,}$",
        "custom_error_message": "Description should not be shorter then 10 characters and should contain alpha-numeric characters in lower case."},
    "primary_key": {
        "mandatory": True, 
        "pattern": "^\[\s*'([a-zA-Z0-9_.+-]+)'\s*(,\s*'([a-zA-Z0-9_.+-]+)')*\s*\]$",
        "custom_error_message": "The primary key field should resemble a list of strings format. The string should use single quotes ONLY. Example: ['prod_key', 'site_key', 'month_end_date']"},
    "kwargs_on_read": {
        "mandatory": False, 
        "pattern": "^(\w+=[\w\s]+)(&\w+=[\w\s]+)*$",
        "custom_error_message": "Keyword arguments for reading should be separated by '&'. Example: 'sep=;&header=true&encoding=cp1251'"},
    "kwargs_on_write": {
        "mandatory": False,
        "pattern": "^(\w+=[\w\s]+)(&\w+=[\w\s]+)*$",
        "custom_error_message": "Keyword arguments for writing should be separated by '&'. Example: 'sep=;&header=true'"},
    "editors": {
        "mandatory": True,
        "condition": None,
        "custom_error_message" : "None"},
    "locality_type": {
        "mandatory": True, 
        "pattern": "^local$",
        "custom_error_message" : "Locality type should be 'local'"},
    "is_technical": {
        "mandatory": True, 
        "list": ["True", "False", True, False], 
        "custom_error_message": "The default type should be either True or False"},
}

# PARAMS FOR POWER BI UPDATE
METADATA_REPORT_GROUP_ID = "69c2ea79-598b-4928-93ae-4867faf47a21"
METADATA_REPORT_DATASET_ID = "ca2bb9d0-369d-4ac5-b5d6-0f7ebffcf7fd"
