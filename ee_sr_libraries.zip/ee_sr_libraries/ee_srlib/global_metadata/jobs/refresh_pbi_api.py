# Databricks notebook source
from ee_srlib.global_metadata.modules.support.email_sender import *
from ee_srlib.global_metadata.modules.config import *
import pandas as pd
import time
import ast

# COMMAND ----------

path_to_power_bi_api = "../../powerbi_api"

# COMMAND ----------

# refresh Power BI
refresh_call_result = dbutils.notebook.run(
    path_to_power_bi_api,
    900,
    {
        "refresh_mode": "regular",
        "groupId": METADATA_REPORT_GROUP_ID,
        "datasetId": METADATA_REPORT_DATASET_ID,
        "api_method": "refresh_pbi",
    },
)

# COMMAND ----------

def waitining_refresh_compleate(group_id: str, dataset_id: str) -> "pd.core.DataFrame":
    """
    Function to check the status of the Pbi update and if it is not complete -> wait until complete
    """
    status_last = "Unknown"
    not_target_status = "Unknown"

    while status_last == not_target_status:
        responce = dbutils.notebook.run(
            path_to_power_bi_api,
            900,
            {
                "api_uri": "https://api.powerbi.com/v1.0/myorg/groups/{groupId}/datasets/{datasetId}/refreshes",
                "groupId": group_id,
                "datasetId": dataset_id,
                "api_method": "get",
            },
        )
        responce_json = ast.literal_eval(responce)
        status_last = responce_json["value"][0]["status"]
        if status_last == not_target_status:
            time.sleep(60)
    logs_df = pd.DataFrame(responce_json["value"])
    return logs_df

# COMMAND ----------

# Get refresh result
refresh_result = waitining_refresh_compleate(
    METADATA_REPORT_GROUP_ID, METADATA_REPORT_DATASET_ID
).head(1)

# COMMAND ----------

last_run_ct_status = refresh_result["status"][0]
cond_check_refresh_result_is_failed = last_run_ct_status == "Failed"

# COMMAND ----------

if cond_check_refresh_result_is_failed:
    err = refresh_result["serviceExceptionJson"][0]
    subject = "[metadata handler][error] Something wrong with Power BI updating"
    
    message = """
    <!DOCTYPE html>
        <html>
            <style>
                .main_table{{
                    font-size:18px; 
                    font-family: "Segoe UI";
                    border-collapse: collapse;
                    width: 800px;
                }}

                .data_type {{
                    width: 228px;
                    border: 1px solid black; 
                    background:#45087b;
                    mso-padding-alt:8px; 
                    color:white
                }}
                
                .data_subtype {{
                    width: 228px;
                    border: 1px solid black; 
                    mso-padding-alt: 8px;
                }}
            </style>

        <br></br>
        <table class="main_table">
            <tr>
                <td class="data_type" rowspan="2" colspan="2" align="center"><b> METADATA POWER BI REFRESH </b></td>
                <td class="data_subtype" rowspan="2" colspan="2" align="center"><b style="color:Red">Metadata PBI refresh FAILED</b></td>
                <td class="data_subtype" rowspan="2" colspan="2" ><b>ERROR:</b> {ERROR}</td>
            </tr>
        </table>
        </html>
    """

    EmailSender().set_message(message.format(ERROR=err)).set_subject(
        subject
    ).set_recipients(DEVS_EMAILS_LIST).send_email(content_type="HTML")