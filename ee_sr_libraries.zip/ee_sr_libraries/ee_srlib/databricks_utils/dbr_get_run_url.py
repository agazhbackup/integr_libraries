import json
from pyspark.sql import SparkSession
from pyspark.dbutils import DBUtils
spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)

def get_run_url():

        """
        Funtion that retrieves URL of the notebook invoked via Jobs/dbutils.notebook.run()

        Returns:
          if run via Jobs/dbutils.notebook.run(): notebook URL
          if run manually: "URL not available" string

        """

        notebook_info = json.loads(
            dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson()
        )
        workspace_url = spark.conf.get("spark.databricks.workspaceUrl")

        try:
            # The tag jobId does not exist when the notebook is not triggered by dbutils.notebook.run(...)
            job_id = notebook_info["tags"]["jobId"]
            org_id = notebook_info["tags"]["orgId"]
            id_in_job = notebook_info["tags"]["idInJob"]
            url = f"https://{workspace_url}/?o={org_id}#job/{job_id}/run/{id_in_job}"

        except KeyError:
            url = "URL not available"

        return url