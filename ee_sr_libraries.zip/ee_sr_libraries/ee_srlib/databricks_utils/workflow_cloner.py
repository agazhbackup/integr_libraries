from databricks.sdk.runtime import *
from itertools import chain
from typing import Literal
import requests
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)


Json = dict[str, 'Json'] | list['Json'] | str | int | float | bool | None


class InstanceError(Exception):
    "Raises an error when the passed instance is not supported. Instance should be one of the keys in the instance_dict"


class MethodError(Exception):
    "Raises an error when the specified request method is unavailable for the workflow session"


class RequestStatusError(Exception):
    "Raises an error when the server returned a response outside [200, 205)"


class JobDoesNotExistError(Exception):
    "Raises an error when the workflow with the specified name does not exist on the remote instance"


class JobAlreadyExists(Exception):
    "Rasises an error when the workflow with the specified name already exists locally"


class WorkflowSession():
    """
    This class is used to clone a workflow from one Databricks instance to another.
    Note that the API is limited to skim through the last 100 workflows only.
    Note that the methods are not designed to clone the workflows that consist of other workflows.

    Usage example:
    s = WorkflowSession(remote_instance='13dv')  # init WorkflowSession class object to access workflows on LP13DV
    s.list_workflows()  # print a dict of existing workflows and their owners on LP13DV
    s.clone_workflow(workflow_name='workflowName')  # clone a workflow from the remote instance to the current LP
    """
    instance_dict = {
        '11dv': 'adb-7794295033550310.10.azuredatabricks.net',
        '13dv': 'adb-157420984458988.8.azuredatabricks.net',
        '13ut': 'adb-1937708827964710.10.azuredatabricks.net',
        '17dv': 'adb-8011212276046907.7.azuredatabricks.net',
        '18dv': 'adb-34101822888396.16.azuredatabricks.net',
        '23ut': 'adb-2126892928456014.14.azuredatabricks.net',
        '23dv': 'adb-1803764660152281.1.azuredatabricks.net',
        '11prod': 'adb-4240071294257418.18.azuredatabricks.net',
        '13prod': 'adb-778718666766171.11.azuredatabricks.net',
        '17prod': 'adb-6747342998649380.0.azuredatabricks.net',
        '18prod': 'adb-614615265670795.15.azuredatabricks.net',
        '23prod': 'adb-69551275400301.1.azuredatabricks.net'
    }

    def __init__(self, remote_instance: Literal[
        '11dv', '13dv', '13ut', '17dv', '18dv', '23ut', '23dv', '11prod', '13prod', '17prod', '18prod', '23prod']) -> "WorkflowSession":
        """
        Constructor for the WorkflowSession class
            param remote_instance: The URL of the remote Databricks instance. Example: '13dv'
            raises: InstanceError, if passed istance is not in the list of valid instances
        """
        if remote_instance not in self.instance_dict.keys():
            raise InstanceError(f'Remote instance should be one of {[*self.instance_dict.keys()]}')

        self.__default_params = {'limit': 100, 'expand_tasks': True}

        self.remote_instance = self.instance_dict[remote_instance]
        self.local_instance = spark.conf.get('spark.databricks.workspaceUrl')

        if self.remote_instance == self.local_instance:
            raise InstanceError('Remote instance should be different from current instance')

        self.__local_token = dbutils.secrets.get(scope="lp14dv",
                                                 key=f"lp-{''.join([k for k, v in self.instance_dict.items() if v == self.local_instance])}-databricks-token-rotation")
        self.__remote_token = dbutils.secrets.get(scope="lp14dv", key=f"lp-{remote_instance}-databricks-token-rotation")

        self._request_methods = {'GET': ['list', 'get'], 'POST': ['create', 'delete']}
        self.__valid_dbr_methods = list(chain(*self._request_methods.values()))

        self.__remote_workflow_list = [*self.list_workflows().keys()]
        self.__local_workflow_list = [*self.list_workflows(_instance='local').keys()]
        print(f"Sucessfully initialized the session for instance {self.remote_instance}")

    def __correct_status(self, response):
        "Checks that the reponse status is within the specified range"
        return response.status_code in range(200, 205)

    def __request(self, method, _instance='remote', **kwargs):
        if method not in self.__valid_dbr_methods:
            raise MethodError(f"Method {method} not supported. Supported methods are {self.__valid_dbr_methods}")
        instance_url = self.remote_instance if _instance == 'remote' else self.local_instance
        token = self.__remote_token if _instance == 'remote' else self.__local_token

        response = requests.request(method=''.join([k for k, v in self._request_methods.items() if method in v]),
                                        url=f"https://{instance_url}/api/2.1/jobs/{method}",
                                        headers={"Authorization": f"Bearer {token}"},
                                        timeout=30,
                                        **kwargs)
        return response


    def __check_workflow(self, workflow_name, **kwargs):
        "Checks if a workflow exists in the remote Databricks instance"
        if not workflow_name in self.__remote_workflow_list:
            raise JobDoesNotExistError(
                f'The following workflow does not exist: {workflow_name}. Check the workflow name or remote instance: {self.remote_instance}')
        return True

    def replace_webhook_notification_value(self, data):
        if isinstance(data, dict):
            for key in data:
                if key == 'webhook_notifications':
                    data[key] = {}
                else:
                    self.replace_webhook_notification_value(data[key])
        elif isinstance(data, list):
            for item in data:
                self.replace_webhook_notification_value(item)

    def list_workflows(self, **kwargs):
        "Returns a dict of the last 100 workflows and their owners in the remote instance"
        response = self.__request('list', **kwargs)
        if not self.__correct_status(response):
            raise RequestStatusError(
                f'Server error: server returned a response outside [200, 205).\n\tExited with status code: {response.status_code}\n\tExited with response: {response.json()}')
        workflows = response.json()
        d = {}
        for i in range(len(workflows['jobs'])):
            d[workflows['jobs'][i]['settings']['name']] = workflows['jobs'][i]['creator_user_name']
        return d


    def get_workflow_id(self, workflow_name: str) -> int:
        """
        Returns the workflow ID based on the workflow name.
            param workflow_name: str, a name of the workflow from the remote instance
            raises: JobDoesNotExistError, if workflow with the passed name does not exist on the remote instance
            returns: int, a workflow ID
        """
        self.__default_params.update({'name': workflow_name})
        if self.__check_workflow(workflow_name):
            response = self.__request('list', params=self.__default_params)
            if self.__correct_status(response):
                return response.json()['jobs'][0]['job_id']

    def get_workflow(self, workflow_name: str, **kwargs) -> Json:
        """
        Returns a job parameters & settings in a JSON format
        param workflow_name: str, a name of the workflow from the remote instance
        raises: JobDoesNotExistError, if workflow with the passed name does not exist on the remote instance
        returns: Json of a non-static format
        """
        if self.__check_workflow(workflow_name, **kwargs):
            workflow_id = self.get_workflow_id(workflow_name)
            self.__default_params.update({'job_id': workflow_id})
            response = self.__request('get', params=self.__default_params)
            if self.__correct_status(response):
                return response.json()
        return None

    def remote_workflow_exists(self, workflow_name, **kwargs):
        """
        Checks if a workflow exists in the remote Databricks instance
        param workflow_name: str, a name of the workflow from the remote instance
        returns:
        """
        msg = f"[True] {workflow_name} workflow exists in the remote instance"
        try:
            if self.__check_workflow(workflow_name, **kwargs):
                print(msg)
                return True
        except JobDoesNotExistError:
            msg = f"[False] {workflow_name} workflow does not exist in the remote instance"
            print(msg)
            return False

    def clone_workflow(self, workflow_name: str) -> None:
        """
        Clones a workflow from the remote Databricks instance into a local instance.
            param workflow_name: str, a name of the workflow from the remote instance
            raises:
                RequestStatusError, if status code for the reuqest is outside of the specified bounds
                JobDoesNotExistError, if the specified workflow does not exist in the remote instance
                JobAlreadyExists, if the specified workflow already exists in the local instance
            returns: None
        """
        if workflow_name in self.__local_workflow_list:
            raise JobAlreadyExists(f"The following workflow already exists in the local instance: {workflow_name}")
        if self.__check_workflow(workflow_name):
            wrkfl_json = self.get_workflow(workflow_name=workflow_name)["settings"]
            self.replace_webhook_notification_value(wrkfl_json)
            response = self.__request(method='create', _instance='local', params=self.__default_params, json=wrkfl_json)
            if self.__correct_status(response):
                msg = f"Successfully cloned the following workflow: {workflow_name}"
                print(msg)
                return None
            else:
                raise RequestStatusError(
                    f"Failed to create workflow {workflow_name}. Server returned a response outside [200, 205).\n\tExited with status code: {response.status_code}\n\tExited with response: /{response.json()}")

    def delete_workflow(self, workflow_name: str) -> None:
        """
        Deletes a workflow from the local Databricks instance.
        param workflow_name: str, a name of the workflow from the local instance
        raises:
                RequestStatusError, if status code for the reuqest is outside of the specified bounds
                JobDoesNotExistError, if the specified workflow does not exist in the local instance
        returns: None
        """
        if workflow_name not in self.__local_workflow_list:
            raise JobDoesNotExistError(f'Workflow {workflow_name} does not exist in the local instance')
        # this part is intended to identify the job id in the local instance, because conventional get_workflow_id method works only for remote instance
        response = self.__request(method='list', _instance='local', params=self.__default_params)
        if self.__correct_status(response):
            for job in response.json()['jobs']:
                if job['settings']['name'] == workflow_name:
                    workflow_id = job['job_id']
        self.__default_params.update({'job_id': workflow_id})
        # this part is for direct deletion
        response = self.__request(method='delete', _instance='local', params=self.__default_params)
        if not self.__correct_status(response):
            print(f"Successfully deleted the following workflow: {workflow_name}")
            return None
        else:
            raise RequestStatusError(
                f"Failed to delete the workflow {workflow_name}. Server returned a response outside [200, 205).\n\tExited with status code: {response.status_code}\n\tExited with response: /{response.json()}")