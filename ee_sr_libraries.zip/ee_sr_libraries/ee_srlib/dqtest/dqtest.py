from tabulate import tabulate
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
import inspect

spark = SparkSession.builder.getOrCreate()

class SparkDataQualityTest:

    """
    This class is designed for checking data quality in tables.
    When the class is initiated, an object of the data frame to be checked is created
    and this object is validated using methods of the class.

    [NOTE]: You need to install tabulate library on your cluster to use this code

    Basic methods for data validation:

     - test_duplicates : You can check for duplicates in a given list of columns.

     - test_nulls: You can test for null values in a column list by using this method.

     - test_values_in_set: Thanks to this method you can check if the values of the
     passed column are within a certain array

     - test_values_not_in_set: With this test you can check that your columns do not
     contain values from the passed list

     - test_str_column_contains_space: With this method you can test your string columns
     for the presence of spaces at the beginning or end of the string.

     - test_column_value_between: With this method you can check if your column values are
     in the specified range.

     - test_is_dataframe_empty: This function checks number of rows in dataframe.
    If number of rows is 0 - Failed.

    You can find more details with the help(< method name >) command
    """

    def __init__(self, df: DataFrame):
        self.df = df.cache()

    def df_to_string_format(self, df: DataFrame) -> str:

        """
        This function is used to generate a string as a table using the tabulate library.
        It converts a sparse dataframe into a tuple list and builds a string table based on the received data.

        Args:
            df[spark.sql.DataFrame]:Spark dataframe with unvalid rows

        Returns:
            [str]: Table converted to string type
        """
        return tabulate(df.collect(), headers=df.columns, tablefmt="grid")

    def create_result(self, test_res: bool, test_context: str):

        """
        This function is designed to dump validation results into a dictionary with 2 keys < success > and < context >.

        Args:
            test_res[bool]: The result of passing the test in boolean terms
            test_context[str|None]: String table with unvalid rows.

        Returns:
            [dict]: Dictionary collected validation result
        """

        return {"success": test_res, "context": test_context}

    def test_duplicates(self, primary_key: list, cols_to_context: list = None):

        """
        This function checks the data for duplicates across the list of columns.

        Args:
            primary_key[list]: List of columns with a unique row key,
            cols_to_context[list]: List of columns to be shown as a result of validation,
            by default None
        Returns:
            [dict]: Validation result
        """

        frame = inspect.currentframe().f_code.co_name
        test = (
            self.df.groupBy(primary_key)
            .agg((count("*")).alias("frequency"))
            .where(col("frequency") > 1)
            .withColumns({"test_name": lit(frame), "test_result": lit("FAILED")})
        )
        if cols_to_context is not None:
            test = test.join(self.df.select(primary_key + cols_to_context), primary_key)

        if not test.isEmpty():
            return self.create_result(False, self.df_to_string_format(test))
        else:
            return self.create_result(True, None)

    def test_nulls(self, columns_list: list):

        """
        This function checks the data for null values across the list of columns.

        Args:
            primary_key[list]: List of columns for nulls test
        Returns:
            [dict]: Validation result
        """

        frame = inspect.currentframe().f_code.co_name
        not_valid_columns = []
        for col_ in columns_list:
            t_col = self.df.where(col(col_).isNull()).count()
            if t_col > 0:
                not_valid_columns.append((col_, t_col))

        n_nullable_columns = len(not_valid_columns)
        if n_nullable_columns > 0:
            test = spark.createDataFrame(
                not_valid_columns, ["column", "n_null_values"]
            ).withColumns({"test_name": lit(frame), "test_result": lit("FAILED")})
            return self.create_result(False, self.df_to_string_format(test))
        else:
            return self.create_result(True, None)

    def test_values_in_set(
        self, column_to_test: str, set_to_compare: list, cols_to_context: list = None
    ):

        """
        This function is used to check that the column data is in the specified set.

        Args:
            column_to_test[str]: Test column
            set_to_compare[list]: A list of values that the data in the column should match
            cols_to_context[list]: List of columns to be shown as a result of validation,
            by default all columns in the table

        Returns:
            [dict]: Validation result
        """

        if cols_to_context == None:
            cols_to_context = self.df.columns
        frame = inspect.currentframe().f_code.co_name
        test = (
            self.df.where(col(column_to_test).isin(set_to_compare) == False)
            .select(cols_to_context)
            .withColumns({"test_name": lit(frame), "test_result": lit("FAILED")})
        )
        if not test.isEmpty():
            return self.create_result(False, self.df_to_string_format(test))
        else:
            return self.create_result(True, None)

    def test_values_not_in_set(
        self, column_to_test: str, set_to_compare: list, cols_to_context: list = None
    ):

        """
        This function checks that the data in the column does not contain
        the values specified in the passed array

        Args:
            column_to_test[str]: Test column
            set_to_compare[list]: A list of values that the data in the column should not match
            cols_to_context[list]: List of columns to be shown as a result of validation,
            by default all columns in the table

        Returns:
            [dict]: Validation result
        """

        if cols_to_context == None:
            cols_to_context = self.df.columns
        frame = inspect.currentframe().f_code.co_name
        test = (
            self.df.where(col(column_to_test).isin(set_to_compare))
            .select(cols_to_context)
            .withColumns({"test_name": lit(frame), "test_result": lit("FAILED")})
        )
        if not test.isEmpty():
            return self.create_result(False, self.df_to_string_format(test))
        else:
            return self.create_result(True, None)

    def test_str_column_contains_space(self, column_to_test: str, func=trim):

        """
        This function checks for spaces at the beginning and end of a string row

        Args:
            column_to_test[str]: Test column
            func: func to test [trim, rtrim, ltrim]. Default trim

        Returns:
            [dict]: Validation result
        """

        frame = inspect.currentframe().f_code.co_name
        test = (
            self.df.select(column_to_test)
            .distinct()
            .withColumn("check_initial", length(col(column_to_test)))
            .withColumn("check", length(func(col(column_to_test))))
            .where(col("check_initial") > "check")
            .drop("check_initial", "check")
            .withColumns({"test_name": lit(frame), "test_result": lit("FAILED")})
        )
        if not test.isEmpty():
            return self.create_result(False, self.df_to_string_format(test))
        else:
            return self.create_result(True, None)

    def test_column_value_between(
        self, column_to_test: str, values: list, cols_to_context: list = None
    ):

        """
        This function checks that the column values are within the specified range

        Args:
            column_to_test[str]: Test column
            values[list]: A list of two values, the first being the minimum value in
            the column and the second the maximum value
            cols_to_context[list]: List of columns to be shown as a result of validation,
            by default all columns in the table

        Returns:
            [dict]: Validation result
        """

        if cols_to_context == None:
            cols_to_context = self.df.columns

        frame = inspect.currentframe().f_code.co_name
        test = (
            self.df.where(col(column_to_test).between(*values) == False)
            .select(cols_to_context)
            .withColumns({"test_name": lit(frame), "test_result": lit("FAILED")})
        )
        if not test.isEmpty():
            return self.create_result(False, self.df_to_string_format(test))
        else:
            return self.create_result(True, None)

    def test_is_dataframe_empty(self):

            """
            This function checks number of rows in dataframe.
            If number of rows is 0 - Failed.
            Returns:
                [dict]: Validation result
            """

            frame = inspect.currentframe().f_code.co_name
            test = self.df.isEmpty()
            if not test:
                return self.create_result(True, None)
            else:
                test = spark.createDataFrame(
                    [(frame, "FAILED", 0)], ["test_name", "test_result", "rows"]
                )
                return self.create_result(False, self.df_to_string_format(test))
