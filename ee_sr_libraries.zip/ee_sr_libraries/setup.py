from setuptools import setup, find_packages

setup(
    name='ee_srlib',
    description='EE Data Team library.',
    version='1.0.0',
    author='ee_data_team',
    packages=find_packages(),
    install_requires=[
        'tabulate',
    ],
)
