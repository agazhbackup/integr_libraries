# Databricks notebook source
# MAGIC %md
# MAGIC # Build package
# MAGIC Run setup and write whl fil to package directory

# COMMAND ----------

# MAGIC %pip install build

# COMMAND ----------

import subprocess

# Build the wheel using build
subprocess.run(['python', '-m', 'build', '--wheel', '--outdir', 'packages'], check=True)

# Clean up the build artifacts
subprocess.run(['rm', '-rf', 'build'], check=True)
subprocess.run(['rm', '-rf', 'ee_srlib.egg-info'], check=True)