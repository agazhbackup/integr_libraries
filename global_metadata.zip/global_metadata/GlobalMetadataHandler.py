# Databricks notebook source
import sys
sys.path.append("/Workspace/Repos/ee-datahub-resilience/share-and-reapply")
sys.path.append("/Workspace/Repos/ee-datahub-resilience/share-and-reapply/global_metadata")

from global_metadata.modules.support.errors import UserInputError
from global_metadata.modules.config import *
from global_metadata.modules.support.usage_logger import *
from global_metadata.modules.base.metadata_reader import *
from global_metadata.modules.base.metadata_writer import *
from global_metadata.modules.base.metadata_parser import *
from typing import Union as UTypes

# COMMAND ----------

gmd_log = MetadataTechLogger(LOG_COLLECTION_PATH)

# COMMAND ----------

class GlobalMetadataHandler:
    def __init__(self):
        self.metadata_info = MetadataParser().get_metadata

    def __check_metadata_code(self, metadata_code: str) -> str:
        try:
            self.metadata_info[metadata_code]
            return metadata_code
        except KeyError:
            raise UserInputError(
                f"This metadata code was not found in the metadata, please add information about it to the metadata or check the correctness of the passed parameter: {metadata_code}"
            )

    def __check_sp_update_condition(self, sp_update: bool) -> bool:
        if isinstance(sp_update, bool):
            return sp_update
        else:
            passed_type = type(sp_update)
            raise UserInputError(
                f"Incorrect parameter indicating synchronisation with sharepoint, the parameter should be of type bool, but is passed: {passed_type}"
            )

    def __check_final_dataframe_type(self, dataframe_type: str) -> str:
        passed_types = ["spark", "pandas"]

        if dataframe_type in passed_types:
            return dataframe_type
        else:
            raise UserInputError(
                f"The invalid parameter indicating the type of dataframe to be passed should be < {' or '.join(passed_types)} > , but it is passed: {dataframe_type}"
            )
    
    def __check_data_is_active(self, metadata_code: str) -> None:
        if self.metadata_info[metadata_code]["is_active"] == False:
            raise UserInputError(
                f"Attempt to interact with inactive data, please change the status of the data in the metadata or check the passed code: {metadata_code}"
            )
    

    def __set_up_manageable_params(self, **kwargs) -> dict:

        manageable_params = dict()
        manageable_params["sp_update"] = self.__check_sp_update_condition(
            kwargs.get("sp_update") if kwargs.get("sp_update") is not None else False
        )
        manageable_params["dataframe_type"] = self.__check_final_dataframe_type(
            kwargs.get("dataframe_type") or "spark"
        )
        manageable_params["sp_username"] = kwargs.get("sp_username") or SP_USERNAME
        manageable_params["sp_password"] = kwargs.get("sp_password") or SP_PASSWORD
        manageable_params["file_mask"] = kwargs.get("file_mask") or ""
        manageable_params["sp_mask"] = kwargs.get("sp_mask") or ""
        manageable_params["local_only"] = self.__check_sp_update_condition(
            kwargs.get("local_only") if kwargs.get("local_only") is not None else False
        )

        return manageable_params

    @gmd_log.action_logging
    def read_file(
        self, metadata_code: str, **kwargs
    ) -> UTypes["pd.DataFrame", "spark.DataFrame"]:
        
        """
        Additional kwargs list:
            sp_update[bool]: True/False, is data needed to be updated from SP, Default: False
            file_mask[str]: Str mask for * dynamic replacement  in file name, Default: ""
            dataframe_type[str]: Returns result type: spark or pandas, Default: spark
            sp_username[str]: Email for SP connecting, Default: eehubingestion.im@pg.com
            sp_password[str]: Password for SP connecting, Default: password for eehubingestion.im
            local_only[bool]: Parameter for shared data - helps to load data from local source
        """

        metadata_code = self.__check_metadata_code(metadata_code)
        self.__check_data_is_active(metadata_code)
        core_data_context = self.metadata_info[metadata_code]
        manageable_kwargs = self.__set_up_manageable_params(**kwargs)
        metadata_context = core_data_context | manageable_kwargs
        for _ in manageable_kwargs.keys(): kwargs.pop(_, None)

        return MetadataReader(metadata_context = metadata_context, **kwargs).get_data()

    @gmd_log.action_logging
    def write_file(
        self, df: Union["pd.DataFrame", "spark.DataFrame"], metadata_code: str, **kwargs
    ) -> None:
        """
        Additional kwargs list:
            sp_update[bool]: True/False, is data needed to be updated from SP, Default: False
            file_mask[str]: Str mask for * dynamic replacement  in file name, Default: ""
            dataframe_type[str]: Returns result type: spark or pandas, Default: spark
            sp_mask[str]: Str mask for * dynamic replacement  in sharepoint path name, Default: ""
            sp_username[str]: Email for SP connecting, Default: eehubingestion.im@pg.com
            sp_password[str]: Password for SP connecting, Default: password for eehubingestion.im
            local_only[bool]: Parameter for shared data - helps to write data only in local destination
        """
        metadata_code = self.__check_metadata_code(metadata_code)
        self.__check_data_is_active(metadata_code)
        core_data_context = self.metadata_info[metadata_code]
        manageable_kwargs = self.__set_up_manageable_params(**kwargs)
        manageable_kwargs["notebook_current_run_key"] = gmd_log.notebook_run_key
        metadata_context = core_data_context | manageable_kwargs
        for _ in manageable_kwargs.keys(): kwargs.pop(_, None)

        return MetadataWriter(df = df, metadata_context = metadata_context, **kwargs).write_data()

    @gmd_log.action_logging
    def get_metadata_properties(self, metadata_code) -> dict:
        """
        Use this method to extract all properties associated with metadata_code (e.g. blob_path, file_format, etc)

        Args:
            metadata_code[str]: code from EEMetadataRegistry
        
        Returns:
            dict: dictionary with properties
        """
        metadata_code = self.__check_metadata_code(metadata_code)
        return self.metadata_info[metadata_code]

    def script_exit(self, exit_result):
        """
        Use this function at the end of all scripts with GlobalMetadataHandler for correct logging.
        """
        return gmd_log.exit_from_notebook(exit_result)
    
    def sdl_check_dq(self, df: "spark.DataFrame", metadata_code: str) -> tuple[bool,str]:
        """
        Use this function to perform Data Quality tests as separate functionality.
        ATTENTION: writing shared (SDL) datasets invokes DQ tests automatically, so use this function for testing purposes or for complex unit testing scenarios.

        Args:
            df[spark.DataFrame]: dataframe to test
            metadata_code[str]: code from EEMetadataRegistry
        
        Returns:
            bool: True if DQ gate passed, Fasle otherwise
            str: empty if DQ gate passed, tabulated summary of issues otherwise
        """

        metadata_code = self.__check_metadata_code(metadata_code)
        self.__check_data_is_active(metadata_code)
        core_data_context = self.metadata_info[metadata_code]

        return SharedDatasetsHandler(df = df, metadata_context = core_data_context, kwargs_for_writing = {}).check_dq()

# COMMAND ----------

GMH = gmh = GlobalMetadataHandler()