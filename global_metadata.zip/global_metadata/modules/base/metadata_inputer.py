import re
from inspect import getsource
from databricks.sdk.runtime import *
from global_metadata.modules.config import *
from global_metadata.modules.support.errors import *
from global_metadata.modules.support.email_sender import *
from global_metadata.modules.support.tables_connector import *

class MetadataInput:
    def __init__(self, modify_existing=False):
        self.__azt = AzureTablesBaseConnector(storage=STORAGE_ACCOUNT, sas_key=TABLES_SAS_KEY_WRITE)
        self.__metadata_info = self.__azt.get_table_content(METADATA_CORE_TABLE_NAME)
        self.metadata_code = self._get_meatadata_code()
        self.modify_existing = modify_existing
        self.metadata_existing = self._get_existing_metadata()  # throw an error at object initialisation step if modify_existing is incorrectly specified
        self.metadata_input = self._prep_input() # filtered version of a input dict + adding some static class attributes to it
        self._check_mandatory_fields() # throw an error at object initialisation step if not all mandatory steps are filled
        self._run_checks()

    def _get_meatadata_code(self):
        return self._get_input()['RowKey']
    
    def _get_curr_editor(self):
        return (
            dbutils.notebook.entry_point.getDbutils()
            .notebook()
            .getContext()
            .userName()
            .get()
        )

    def _get_editors(self, form='str'):
        editors = set()
        if self.modify_existing and self.metadata_existing:
            pattern = re.compile("\\[|\\]|\\'")
            editors = set([_.strip() for _ in re.sub(pattern, '', self.metadata_existing['editors']).split(',')])
        editors.add(self._get_curr_editor())
        if form == 'list':
            return list(editors)
        return str(list(editors))

    # data preparation start
    def _get_input(self):
        return dict(dbutils.notebook.entry_point.getCurrentBindings())

    def _remove_empty_input(self, d: dict):
        return {k: v for k, v in d.items() if str(v).strip() != ""}

    def _add_static_attrs(self, d: dict) -> dict:
        "Adds static, unmodifiable attributes to the metadata input dictionary"
        d["PartitionKey"] = "EE"
        d["locality_type"] = "local"
        d["is_shared"] = "False"
        d['is_technical'] = "False"
        d["editors"] = self._get_editors()
        return d

    def _change_str_to_bool(self, d):
        """
        Converts default widget 'True', 'False' values to True/False 
        for all boolean fields (starting with 'is_')  
        """
        mapper = {"True":True, "False":False}
        bool_field = lambda x : x.startswith("is_")    
        for k,v in d.items():
            if bool_field(k) and not isinstance(d[k], bool):
                d[k] = mapper[v]
        return d
    
    def _apply_existing_metadata(self, metadata_input, metadata_existing):
        """
        For existing metadata code, fills empty widget values with existing data. 
        This is done so that when you change a one field for a metadata code, 
        you won't have to manually re-fill all the fields.
        """
        if self.modify_existing:
            metadata_difference = dict(set(metadata_existing.items()) - set(metadata_input.items()))
            if bool(metadata_difference):
                for k, v in metadata_difference.items():
                    if metadata_input[k] == "":
                        metadata_input[k] = v
        return metadata_input

    def _prep_input(self):
        d = self._get_input()
        d = self._add_static_attrs(d)
        d = self._change_str_to_bool(d)
        d = self._apply_existing_metadata(d, self.metadata_existing)
        d = self._remove_empty_input(d)
        return d
    # data preparation end

    # global checks start
    def _check_metadata_code_exists(self) -> [False, dict]:
        """
        Checks the condition that if metadata code exists then modify_existing parameter is set to True and vise versa.
        raises: UserInputError, if metadata code exists and modify_existing == False | if metadata code does not exist and modify_existing == True
        returns: existing_md : dict(), existing data for the given metadatacode
        """
        code_exists = False
        if self.metadata_code in [_["RowKey"] for _ in self.__metadata_info]:
            code_exists = True
            if not self.modify_existing:
                raise UserInputError(
                    f"Attempting to overwrite the existing metadata code: {self.metadata_code}. If this is not a mistake, pass the argument 'modify_existing=True'")
        if (
            self.metadata_code not in [_["RowKey"] for _ in self.__metadata_info]
            and self.modify_existing
        ):
            raise UserInputError(
                f"Inconsistency detected. Metadata code {self.metadata_code} is not present in the table, however modify_existing parameter is set to {self.modify_existing}"
            )
        return code_exists

    def _get_existing_metadata(self):
        if self._check_metadata_code_exists():
            metadata_existing = [_ for _ in self.__metadata_info if _["RowKey"] == self.metadata_code][0]
            metadata_existing.pop("Timestamp")
            return metadata_existing
        else:
            return None
    
    def _check_mandatory_fields(self):
        """
        Checks that all mandatory fields are in the 'metadata_input' variable.
        This function uses set difference because optional widget inputs should not affect it.
        """
        mandatory_fields = [
            k for k, v in METADATA_FIELDS_PROPERTIES.items() if v["mandatory"] == True
        ]
        non_empty_inputs =  [
            k for k, v in self.metadata_input.items() if str(v).strip() != ""
        ]

        if bool(set(mandatory_fields) - set(non_empty_inputs)):
            raise UserInputError(
                f"Not all mandatory fields are filled. Missing fields: {set(mandatory_fields) - set(non_empty_inputs)}"
            )
    # global checks end

    # abstract checks start
    def _check_field_exists(self, field: str) -> [str, False]:
        """Checks if the metadata field exists
        param field : string, metadata field string
        returns: field name if exists, false otherwise
        """
        try:
            return self.metadata_input[field]
        except KeyError:
            return False

    def _check_field_by_pattern(self, field: str) -> None:
        pattern = METADATA_FIELDS_PROPERTIES[field]["pattern"]
        if not re.fullmatch(pattern, self.metadata_input[field]):
            raise UserInputError(
                f"Incorrect pattern for field '{field}'. Please make sure that you fill the field with the appropriate pattern: {pattern}. Extended traceback: {METADATA_FIELDS_PROPERTIES[field]['custom_error_message']}"
            )

    def _check_field_by_list(
        self,
        field: str,
    ):
        valid_list = METADATA_FIELDS_PROPERTIES[field]["list"]
        if not self.metadata_input[field] in valid_list:
            raise UserInputError(
                f"Incorrect value for field '{field}'. Please make sure that the value is among {valid_list}. Extended traceback: {METADATA_FIELDS_PROPERTIES[field]['custom_error_message']}"
            )

    def _check_field_by_condition(self, field):
        condition = METADATA_FIELDS_PROPERTIES[field]["condition"]
        if not condition(self.metadata_input[field]):
            raise UserInputError(
                f"Condition for field '{field}' is not satisfied. Please make sure that the value complies with {getsource(condition)}. Extended traceback: {METADATA_FIELDS_PROPERTIES[field]['custom_error_message']}"
            )
    # abstract checks end

    # field checks start
    def _check_partition_key(self):
        self._check_field_by_pattern("PartitionKey")

    def _check_row_key(self):
        self._check_field_by_pattern("RowKey")
    
    def _check_meta_type(self):
        self._check_field_by_list("type")
    
    def _check_raw_bool(self):
        self._check_field_by_list("is_raw")

    def _check_shared_bool(self):
        self._check_field_by_list("is_shared")

    def _check_iaf_data_type(self):
        self._check_field_by_list("iaf_data_type")
    
    def _check_data_classification(self):
        self._check_field_by_list("data_classification")

    def _check_application_id(self):
        self._check_field_by_pattern("application_id")

    def _check_owners(self):
        self._check_field_by_pattern("owners")

    def _check_source_lp_id(self):
        self._check_field_by_list("source_lp_id")

    def _check_refresh_schedule(self):
        self._check_field_by_pattern("refresh_schedule")

    def _check_retention_policy(self):
        if self.metadata_input["retention_policy"] == 'inf':
            if self.metadata_input['type'] == 'fact':
                raise UserInputError('Attempting to set infinite retention policy on fact data. Please, enter the appropriate retention policy for facts.')
        else:
            self._check_field_by_pattern("retention_policy")

    def _check_active_bool(self):
        self._check_field_by_list("is_active")

    def _check_generic_source(self):
        self._check_field_by_list("generic_source")

    def _check_blob_path(self):
        self._check_field_by_condition("blob_path")

    def _check_file_name(self):
        if self._check_field_exists("file_name"):
            file_format = self.metadata_input["file_format"]
            # corner case: delta does not support file naming
            if file_format == "delta":
                raise UserInputError(
                    f"Inconsistency detected. Can't specify file name if file format is {file_format}"
                )
            # check consistency between file name and file format.
            # if len == 1, then we assume file name is a mask
            # if len > 1, then the last index of the list should correspond to any approved file format
            splitted_file_name = self.metadata_input["file_name"].split(".")
            approved_formats = METADATA_FIELDS_PROPERTIES["file_format"]["list"]
            if (
                len(splitted_file_name) > 1
                and splitted_file_name[-1] not in approved_formats
            ):
                raise UserInputError(
                    f"Inconsistency detected. The specified file format is {file_format} not among {approved_formats}"
                )
            if len(splitted_file_name) > 1 and splitted_file_name[-1] != file_format:
                raise UserInputError(
                    f"Inconsistency detected. The specified file format is {file_format}, while specified file name ends with {splitted_file_name[-1]}"
                )
        
    def _check_file_format(self):
        self._check_field_by_list("file_format")

    def _check_sp_path(self):
        "Checks that the passed SP path is valid via sending a reuqest to it"
        if self._check_field_exists("sharepoint_path"):
            self._check_field_by_condition("sharepoint_path")

    def _check_sp_name(self):
        if self._check_field_exists("sharepoint_name"):
            self._check_field_by_condition("sharepoint_name")

    def _check_sheet_name(self):
        if self._check_field_exists("sheet_name"):
            file_format = self.metadata_input["file_format"]
            if file_format != "xlsx":
                raise UserInputError(
                    f"Cannot specify sheet name if file format is not .xlsx. Provided file format: {file_format}"
                )
            self._check_field_by_condition("sheet_name")
 
    def _check_dbr_table_name(self):
        "Checks that the database and table are passed using the appropriate format: database.table"
        if self._check_field_exists("dbr_table_name"):
            self._check_field_by_pattern("dbr_table_name")

    def _check_description(self):
        self._check_field_by_pattern("description")

    def _check_refresh_duration(self):
        if self._check_field_exists("refresh_duration"):
            self._check_field_by_pattern("refresh_duration")

    def _check_primary_key(self):
        if not self.metadata_input['is_raw']:
            self._check_field_by_pattern("primary_key")

    def _check_kwargs_on_read(self):
        if self._check_field_exists("kwargs_on_read"):
            self._check_field_by_pattern("kwargs_on_read")

    def _check_kwargs_on_write(self):
        if self._check_field_exists("kwargs_on_write"):
            self._check_field_by_pattern("kwargs_on_write")

    def _check_metadata_locality(self):
        "Checks that the modification is done on a local metadata code. Out of scope codes can be modified only via a separate process"
        self._check_field_by_pattern("locality_type")

    def _check_technical_bool(self):
        self._check_field_by_list("is_technical")
    # field checks end

    # consolidated checks
    def _run_checks(self):
        self._check_partition_key()
        self._check_row_key()
        self._check_meta_type()
        self._check_raw_bool()
        self._check_shared_bool()
        self._check_iaf_data_type()
        self._check_data_classification()
        self._check_application_id()
        self._check_owners()
        self._check_source_lp_id()
        self._check_refresh_schedule()
        self._check_retention_policy()
        self._check_active_bool()
        self._check_generic_source()
        self._check_blob_path()
        self._check_file_name()
        self._check_file_format()
        self._check_sp_path()
        self._check_sp_name()
        self._check_sheet_name()
        self._check_dbr_table_name()
        self._check_description()
        self._check_refresh_duration()
        self._check_primary_key()
        self._check_kwargs_on_read()
        self._check_kwargs_on_write()
        self._check_metadata_locality()
        self._check_technical_bool()

    def _generate_input_feedback(self):
        html_str = """
        <!DOCTYPE html>
        <html>
            <style>
                .main_table{{
                    font-size:18px; 
                    font-family: "Segoe UI";
                    border-collapse: collapse;
                    width: 800px;
                }}
            
                .values_insert {{
                    padding: 10px;
                    border: 1px solid; 
                }}

                .data_header {{
                    font-size: 26px;
                    font-weight: bold;
                    background: burlywood;
                }}

                .data_type {{
                    width: 228px;
                    border: 1px solid black; 
                    background:#45087b;
                    mso-padding-alt:8px; 
                    color:white
                }}
                
                .data_subtype {{
                    width: 228px;
                    border: 1px solid black; 
                    mso-padding-alt: 8px; 
                    color:black
                }}
            </style>

        <table class="main_table">
            <tr>
                <td class="data_type" rowspan="2" colspan="2" align="center"><b> METADATA INPUT STATUS </b></td>
                <td class="data_subtype" rowspan="2" colspan="2" align="center">Your metadata code has been <b>{status}</b></td>
                <td class="data_subtype" rowspan="2" colspan="2" align="center">Metadata code: <b>{metadata_code}</b></td>
            </tr>
        </table>
        
        <br></br>

        <table class="main_table" >
            <thead>
                <tr>
                    <th class="values_insert">Field</th>
                    <th class="values_insert">Value</th>
                    <th class="values_insert">Status</th>
                </tr>
            </thead>
                <tbody >
                    {_BODY}
                </tbody>
        </table>
        </html>
        """
        collector = []
        for k,v in self.metadata_input.items():
            field_cell = f"""<td class="values_insert">{k}</td>"""
            value_cell = f"""<td class="values_insert">{v}</td>"""
            status_cell = """<td class="values_insert" align="center">OK</td>"""
            collector.append(
                    f"""<tr style="border: 1px solid black;">{field_cell}{value_cell}{status_cell}</tr>""")
        res = html_str.format(
            metadata_code = self.metadata_input.get('RowKey'),
            status = ['UPDATED' if self.modify_existing else 'UPLOADED'][0],
            _BODY="".join(collector))
        return res

    def _send_input_feedback(self):
        feedback = self._generate_input_feedback()
        mailing_list = self._get_editors(form='list')
        email = EmailSender()
        email.set_message(feedback)
        email.set_subject('[METADATA] Metadata input notification')
        email.set_recipients(mailing_list)
        email.send_email(content_type='html')
        displayHTML(feedback)

    def push_metadata(self):
        self._run_checks()
        self.__azt.put_table_content(
            table_name=METADATA_CORE_TABLE_NAME, content=self.metadata_input
            )
        self._send_input_feedback()
        return True