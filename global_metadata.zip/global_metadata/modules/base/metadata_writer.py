from global_metadata.modules.support.errors import *
from global_metadata.modules.base.metadata_parser import *
from global_metadata.modules.support.sp_connector import *
from global_metadata.modules.support.email_sender import *
from global_metadata.modules.config import *
from datetime import datetime
from typing import Union
import pandas as pd
import os
import io
import re
import pyspark.sql.functions as f
from tabulate import tabulate
import pyspark
from IPython.display import HTML
from pyspark.sql.window import Window

from pyspark.sql.types import (
    StructField,
    StructType,
    StringType,
    IntegerType,
    TimestampType,
)

class WriteSupportFunctions:

  """
  Generic class for write-purpose functions.
  """

  def __init__(self, metadata_context: dict) -> None:
    self.metadata_context = metadata_context

  @property
  def define_kwargs_for_writing(self) -> dict:

    try:
      kwargs_write = self.metadata_context["kwargs_on_write"].split("&")
      kwargs_write = {
          i.split("=")[0].strip(): i.split("=")[1].strip()
          for i in kwargs_write
          if "=" in i
      }

      # transform string to list
      if 'partitionBy' in kwargs_write.keys():
        modified = re.sub(r"[\[\]']", "", kwargs_write['partitionBy']).split(',')
        kwargs_write['partitionBy'] = [_.strip() for _ in modified]

    except KeyError:
      kwargs_write = {}
    
    return kwargs_write
  
  @property
  def _check_table(self) -> bool:
    return "dbr_table_name" in self.metadata_context.keys()
  
  @property
  def _check_file_name(self) -> bool:
    if "file_name" not in self.metadata_context.keys():
      return False
    else:
      self.metadata_context['file_name'] = self.metadata_context["file_name"].replace("*", self.metadata_context["file_mask"])
      if not self.metadata_context['file_name'].endswith(f".{self.metadata_context['file_format']}"):
        self.metadata_context['file_name'] = f"{self.metadata_context['file_name']}.{self.metadata_context['file_format']}"
      return True
  
  @property
  def _check_sp_metadata(self) -> bool:
    if not ("sharepoint_name" in self.metadata_context.keys() and "sharepoint_path" in self.metadata_context.keys()):
      return False
    else:
      self.metadata_context['sharepoint_path'] = self.metadata_context["sharepoint_path"].replace("*", self.metadata_context["sp_mask"])
      return True
  
  def send_email(self, subject: str, message: str, content_type: str = "HTML") -> None:
    EmailSender().set_message(message).set_subject(subject).set_recipients(self.metadata_context['owners']).send_email(content_type=content_type)

  def create_dir(self) -> None:
    if not os.path.exists(f"/dbfs{self.metadata_context['blob_path']}"):
      os.makedirs(f"/dbfs{self.metadata_context['blob_path']}")
  

class Writers(WriteSupportFunctions):

  """
  Class with methods for writing data - spark, panads, SharePoint.
  """

  def __init__(self, df: Union["pd.DataFrame", "spark.DataFrame"], dataframe_type: str, metadata_context: dict) -> None:
    self.metadata_context = metadata_context
    self.df = df

  def spark_table_writer(self) -> None:
    """
    This function is for writing data to Blob and creating table from it
    """

    self.df.write.saveAsTable(name = self.metadata_context["dbr_table_name"], format = self.metadata_context["file_format"], path = self.metadata_context["blob_path"], **self.kwargs_for_writing)

  def spark_blob_writer(self) -> None:
    """
    This function is for writing data to Blob only
    """

    self.df.write.save(path = self.metadata_context["blob_path"], format = self.metadata_context["file_format"], **self.kwargs_for_writing)

  def pandas_csv_writer(self) -> None:
    """
    This function is for writing data to Blob as single CSV file 
    """

    # add default args
    if "index" not in self.kwargs_for_writing.keys():
      self.kwargs_for_writing['index'] = False
    if "sep" not in self.kwargs_for_writing.keys():
      self.kwargs_for_writing['sep'] = ';'

    self.df.to_csv(path_or_buf = f"/dbfs{self.metadata_context['blob_path']}/{self.metadata_context['file_name']}", **self.kwargs_for_writing)

  def pandas_excel_writer(self) -> None:
    """
    This function is for writing data to Blob as single excel file 
    """

    # add default args
    if "index" not in self.kwargs_for_writing.keys():
      self.kwargs_for_writing['index'] = False

    # create buffer for writing bytes with Excel writer (most error-safe method)
    bytes_buffer = io.BytesIO()

    # save bytes to buffer
    with pd.ExcelWriter(bytes_buffer, mode='w') as writer:
      self.df.to_excel(excel_writer = writer, sheet_name = self.metadata_context['sheet_name'], **self.kwargs_for_writing)

    # write to Blob from buffer with native Python function
    with open(f"/dbfs{self.metadata_context['blob_path']}/{self.metadata_context['file_name']}", "wb") as file:
      file.write(bytes_buffer.getvalue())

  def sp_basic_writer(self) -> None:
    """
    This function is for writing data to Sharepoint
    """

    # use native Python function to open file as bytes (most error-safe method)
    with open(f"/dbfs{self.metadata_context['blob_path']}/{self.metadata_context['file_name']}", "rb") as file:
      byte_content = file.read()

    # write bytes to Sharepoint
    sp_session = SharePointBaseConnector_MH(self.sp_username, self.sp_password, self.metadata_context['sharepoint_name'], site_type=self.metadata_context["generic_source"])
    
    res = sp_session.post_file(byte_content, self.metadata_context['sharepoint_path'], self.metadata_context['file_name'])

    if res.status_code != 200:
      try:
        err = res.json().get('odata.error').get('message').get('value')
      except:
        err = 'Cannot parse Sharepoint POST error, please reach out to EE DevOps team'
      
      raise SharePointUploadingError(err)

class MetadataWriter(Writers):

  """Main class with all writing logic"""

  def __init__(self, df: Union["pd.DataFrame", "spark.DataFrame"], metadata_context: dict, **kwargs) -> None:
    self.metadata_context = metadata_context
    self.df = df
    self.dataframe_type = metadata_context["dataframe_type"]
    self.sp_update = metadata_context["sp_update"]
    self.sp_username = metadata_context["sp_username"]
    self.sp_password = metadata_context["sp_password"]

    # combine metadata-sourced and directly passed kwargs into one dictionary
    self.kwargs_for_writing = {**self.define_kwargs_for_writing, **kwargs}

    if self.metadata_context["is_raw"]:
      raise UserInputError("This metadata_code is for raw data which cannot be overwritten")
    
  def spark_writer(self) -> None:
    """
    This function is checking if table name is provided in metadata. If yes, writes to blob and creates table, if not - only writes to blob.
    """

    # add default args
    if "mode" not in self.kwargs_for_writing.keys():
      self.kwargs_for_writing['mode'] = 'overwrite'
    
    if self._check_table:
      self.spark_table_writer()
    else:
      self.spark_blob_writer()

  def pandas_writer(self) -> None:
    """
    This function is for writing data with Pandas, converting dataframe if spark dataframe is provided.

    Raises:
      UserInputError if:
        metadata does not contain file_name
        formats other than ['xlsx', 'csv', 'csv.gz'] are provided
    """

    if not isinstance(self.df, pd.DataFrame):
      self.dataframe_type = "pandas"
      self.df = self.df.toPandas()
      print("Converted dataframe to Pandas to use pandas dataframe_type")

    self.create_dir()

    if not self._check_file_name:
      raise UserInputError("Please specify file name in metadata to use pandas dataframe_type")
    
    if self.metadata_context["file_format"] == "xlsx":
      self.pandas_excel_writer()
    elif self.metadata_context["file_format"] in ["csv", "csv.gz"]:
      self.pandas_csv_writer()
    else:
      raise UserInputError("Pandas writer dataframe_type is compatible with following file formats: ['xlsx', 'csv', 'csv.gz']. For other formats, please use default dataframe_type = 'spark'")

  def sharepoint_writer(self) -> None:
    """
    This function is for writing data to Sharepoint.
    
    Raises:
      UserInputError: if 'sharepoint_name' or 'sharepoint_path' are not provided in metadata
    """
    
    if self._check_sp_metadata:
      self.sp_basic_writer()
      
    else:
      raise UserInputError("Please check that 'sharepoint_name' and 'sharepoint_path' are specified in metadata to post to sharepoint")

  def write_data(self) -> bool:
    """
    Main method with decistion tree of which methods must be used. Also invokes schema registration in metadata.

    Returns:
        True/False if dataset is shared depending on DQ gate results
        True if dataset is non-shared

    Raises:
      InvalidArgument: if incorrect dataframe_type is provided (supported - ['spark', 'pandas'])
    """

    
    if self.dataframe_type == "spark":
      if self.sp_update:
        raise InvalidArgument("Please convert Dataframe to Pandas df to be able to write datasets to Sharepoint")

      self.spark_writer()
      print('Data successfully written to Blob')

    elif self.dataframe_type == "pandas":
      self.pandas_writer()
      print('Data successfully written to Blob')

      if self.sp_update:
        # pandas is used for stability reasons - less error-prone than handling multiple engines
        self.sharepoint_writer()
        print('Data successfully written to Sharepoint')
    else:
      raise InvalidArgument("Please specify one of the following dataframe_types: ['spark', 'pandas']")
    
    if self.metadata_context["is_shared"] and not self.metadata_context["local_only"]:

      return SharedDatasetsHandler(self.df, self.metadata_context, self.kwargs_for_writing).push_to_sdl()
      
    elif not self.metadata_context["is_shared"]:
      # register schema in EESchemaRegistry
      SchemaRegistry(df = self.df, dataframe_type = self.dataframe_type, metadata_context = self.metadata_context).update_schema()
      return True
    

class SchemaRegistry(MetadataWriter):

  """
  Class for registering dataframe schemas on write.
  """

  def __init__(self, df: Union["pd.DataFrame", "spark.DataFrame"], dataframe_type: str, metadata_context: dict) -> None:
    self.df = df
    self.metadata_context = metadata_context
    self.dataframe_type = dataframe_type

    self.registered_schema = self.get_registered_schema()
    self.current_schema = self.get_current_schema()

    # params for sending error messages
    self.error_subject = "[metadata handler][error] Something wrong with uploading DF schema to EESchemaRegistry"
    self.error_message = f"<p>Some error occured when trying to push dataframe schema to EESchemaRegistry for metadata_code = <b>{self.metadata_context['RowKey']}</b>.</p><p>Please contact EE DevOps team.</p>"
    self.print_error = "Something wrong with schema update in EESchemaRegistry.Datasets owner(s) were notified via e-mail. Please contact EE DevOps team."

  def get_current_schema(self) -> list[dict]:
    """
    Retrieve the current schema of the DataFrame.

    Returns:
        list[dict]: A list of dictionaries representing the schema, where each dictionary contains the column name and its data type.
    """

    if self.dataframe_type == "spark":
      raw_schema = self.df.dtypes
    elif self.dataframe_type == "pandas":
      raw_schema = [(k, str(v)) for k,v in self.df.dtypes.to_dict().items()]

    # create schema with the same structure as in EESchemaRegistry
    output_schema = []
    for cl in raw_schema:
      temp = {}
      temp["PartitionKey"] = self.metadata_context["RowKey"]
      temp["RowKey"] = cl[0]
      temp["column_type"] = cl[1]
      temp["dataframe_type"] = self.dataframe_type

      output_schema.append(temp)
    
    return output_schema
  
  def get_registered_schema(self) -> list[dict]:
    """
    Retrieve the registered schema associated with the current instance.

    Returns:
        list[dict]: A list of dictionaries representing the registered schema, where each dictionary contains the schema information.
    """

    azt = AzureTablesBaseConnector(storage = STORAGE_ACCOUNT, sas_key = TABLES_SAS_KEY_WRITE)
    registered_schema = azt.get_filter_table_content(table_name = METADATA_SCHEMA_REGISTRY_NAME, filter_by_property = "PartitionKey", property_value = self.metadata_context["RowKey"])

    # in case no schema is registered
    if len(registered_schema) == 0:
      registered_schema = {}
    
    # keep only certain keys for future like-to-like comparison with current schema
    keys_to_keep = ["PartitionKey", "RowKey", "column_type", "dataframe_type"]
    registered_schema = [{key: item[key] for key in keys_to_keep} for item in registered_schema]

    return registered_schema
  
  @property
  def compare_schemas(self) -> bool:
    """
    Compare the registered schema with the current schema.

    Returns:
        bool: True if the registered schema matches the current schema, False otherwise.
    """

    # convert dicts to tuples to use SET comparison (dicts are not hashable)
    tuple_set_registered = set([tuple(dictionary.items()) for dictionary in self.registered_schema])
    tuple_set_current = set([tuple(dictionary.items()) for dictionary in self.current_schema])

    return tuple_set_registered == tuple_set_current
  
  def delete_schema(self) -> bool:
    """
    Delete the registered schema associated with the current instance.

    Raises:
        Exception: If an error occurs while deleting the schema from EESchemaRegistry.
    """
    
    azt = AzureTablesBaseConnector(storage = STORAGE_ACCOUNT, sas_key = TABLES_SAS_KEY_WRITE)
    res = [azt.delete_row_content(table_name = METADATA_SCHEMA_REGISTRY_NAME, content=cl) == 204 for cl in self.registered_schema]
    if not all(res):
      self.send_email(subject=self.error_subject,
                      message=self.error_message)
      print(self.print_error)
      return False
    return True
  
  def update_schema(self) -> None:
    """
    Update the schema in EESchemaRegistry based on the current DataFrame schema.

    Raises:
        Exception: If an error occurs while updating the schema in EESchemaRegistry.
    """

    # delete previous schema and upload new one if they do not match
    # do nothing if schemas are identical
    if not self.compare_schemas:
      if self.delete_schema():

        azt = AzureTablesBaseConnector(storage = STORAGE_ACCOUNT, sas_key = TABLES_SAS_KEY_WRITE)
        res = [azt.put_table_content(table_name = METADATA_SCHEMA_REGISTRY_NAME, content=cl) == 204 for cl in self.current_schema]
        if not all(res):
          self.send_email(subject=self.error_subject,
                          message=self.error_message)
          print(self.print_error)
          
        print('Schema successfully updated in EESchemaRegistry')

class SharedDatasetsHandler(MetadataWriter):

  """
  Class with methods for handling Shared Single Data Layer datasets.
  """

  def __init__(self, df: pyspark.sql.DataFrame, metadata_context: dict, kwargs_for_writing: dict) -> None:
    self.df = df
    self.metadata_context = metadata_context
    self.kwargs_for_writing = kwargs_for_writing

    if not isinstance(self.df, pyspark.sql.DataFrame):
      raise InvalidArgument("Please convert Dataframe to PySpark df to be able to push shared datasets.")

    self.registered_schema = self.get_registered_schema()
    self.current_schema = self.get_current_schema()

    self.check_spark_df_type()
    self.check_shared_flag()

  def get_registered_schema(self) -> list[dict]:
    """
    Retrieve the registered schema associated with the current instance.

    Returns:
        list[dict]: A list of dictionaries representing the registered schema, where each dictionary contains the schema information.
    """

    azt = AzureTablesBaseConnector(storage = STORAGE_ACCOUNT, sas_key = TABLES_SAS_KEY_WRITE)
    registered_schema = azt.get_filter_table_content(table_name = METADATA_SCHEMA_REGISTRY_NAME, filter_by_property = "PartitionKey", property_value = self.metadata_context["RowKey"])

    # in case no schema is registered
    if len(registered_schema) == 0:
      raise UserInputError("Missing schema EESchemaRegistry. Shared datasets must have registered schema.")

    return registered_schema
  
  @property
  def registered_schema_comparison(self) -> list[dict]:

    """Leaves only needed attributes for schema comparison"""

    keys_to_keep = ["RowKey", "column_type"]
    return [{key: item[key] for key in keys_to_keep} for item in self.registered_schema]
  
  def get_current_schema(self) -> list[dict]:
    """
    Retrieve the current schema of the DataFrame.

    Returns:
        list[dict]: A list of dictionaries representing the schema, where each dictionary contains the column name and its data type.
    """

    raw_schema = self.df.dtypes

    # create schema with the same structure as in EESchemaRegistry
    output_schema = []
    for cl in raw_schema:
      temp = {}
      temp["RowKey"] = cl[0]
      temp["column_type"] = cl[1]

      output_schema.append(temp)
    
    return output_schema
  
  @property
  def compare_schemas(self) -> bool:
    """
    Compare the registered schema with the current schema.

    Returns:
        bool: True if the registered schema matches the current schema, False otherwise.
    """

    # convert dicts to tuples to use SET comparison (dicts are not hashable)
    tuple_set_registered = set([tuple(dictionary.items()) for dictionary in self.registered_schema_comparison])
    tuple_set_current = set([tuple(dictionary.items()) for dictionary in self.current_schema])

    return tuple_set_registered == tuple_set_current
  
  def check_spark_df_type(self) -> None:
    """Check if dataframe_type is Spark for Shared datasets"""
    if not all([x["dataframe_type"] == "spark" for x in self.registered_schema]):
      raise UserInputError("dataframe_type must be set to spark for all Shared dataset columns")
  
  def check_shared_flag(self) -> None:
    """Check if Shared flag is True for every row Shared datasets"""
    if not all([x["is_shared"] for x in self.registered_schema]):
      raise UserInputError("is_shared must be set to True for all Shared dataset columns")
  
  def dq_check_compare_schemas(self) -> str:
    """
    Method for DQ check - schema consistency

    Returns:
      tabulated string with schema check results if schemas don't match, empty string otherwise
    """

    if not self.compare_schemas:
      
      current_schema = pd.DataFrame([tuple(dictionary.values()) for dictionary in self.current_schema], columns=['column_name', 'column_type'])
      registered_schema = pd.DataFrame([tuple(dictionary.values()) for dictionary in self.registered_schema_comparison], columns=['column_name', 'column_type'])

      schema_diff = registered_schema.merge(current_schema, on = 'column_name', how = 'outer', suffixes=('_registered', '_current'))

      schema_diff = schema_diff[(schema_diff['column_type_registered'] != schema_diff['column_type_current'])]

      string_diff = f"<h3>CHECK - compare dataframe schema vs EESchemaRegistry</h3>" + tabulate(schema_diff, headers='keys', tablefmt='html', showindex=False)

    else:
      string_diff = ""

    return string_diff

  def dq_check_primary_key(self) -> str:
    """
    Method for DQ check - duplicates by primary key

    Returns:
      tabulated string with number of duplicated rows (only top 50 are shown), empty string otherwise
    """

    window_spec = Window.partitionBy(self.metadata_context["primary_key"])
    df_count = self.df.withColumn("row_count", f.count("*").over(window_spec))

    duplicates = df_count.filter(f.col("row_count") > 1).select(*self.metadata_context["primary_key"], "row_count").distinct()

    if not duplicates.isEmpty():
        string_count = f"<h3>CHECK - duplicate rows by Primary key</h3>" + tabulate(duplicates.limit(50).toPandas(), headers='keys', tablefmt='html', showindex=False)
    else:
        string_count = ""

    return string_count

  def dq_check_not_nullable_columns(self) -> str:
    """
    Method for DQ check - NULLs in not nullable columns

    Returns:
      tabulated string with number of nulls per column, empty string otherwise
    """

    null_columns = [
        f.sum(f.when(f.col(column['RowKey']).isNull(), 1).otherwise(0)).alias(column['RowKey'])
        for column in self.registered_schema
        if not column['is_nullable'] or column['RowKey'] in self.metadata_context['primary_key']
    ]

    # Aggregate null counts
    null_summary = self.df.agg(*null_columns).collect()[0].asDict()

    # Filter out columns with no nulls
    null_summary = {k: v for k, v in null_summary.items() if v > 0}

    if null_summary:
        string_nulls = f"<h3>CHECK - Null values in non-nullable columns</h3>" + tabulate([[key, value] for key, value in null_summary.items()], headers=["column_name", "count_null_values"], tablefmt='html', showindex=False)
    else:
        string_nulls = ""

    return string_nulls

  def generate_summary(self, *args) -> str:
    """
    Generates CSS-styled HTML summary from individual summaries
    """
    css_styles = {
      "<table>": "<table style='border-collapse: collapse;border: 1px solid;width: 70%;'>",
      "<th>": "<th style='border: 1px solid black;text-align: center;padding: 8px;background: #0070C0;color: white;'>",
      "<td>": "<td style='border: 1px solid black;text-align: center;padding: 8px;'>",
      "<h3>": "<h3 style='background: #F3FF5A;width: 70%;'>",
      }
    code_for_check = self.metadata_context['RowKey']

    initial_message = f"""
    <table>
      <tr> 
        <th rowspan="2" style='padding: 8px;background: burlywood;color: white;width:200px'> EE Metadata Registry </th>
        <th style='padding: 8px;background: #0070C0;color: white'> Data Quality gate for Shared dataset failed </th>
      </tr>
      <tr>
        <td>Metadata code: <b>{code_for_check}</b></td>
      </tr>
    </table>
    """

    err_msg = ''.join([_ for _ in args])

    # replace stadard styles with empty ones
    err_msg = re.sub(r'(<th\b[^>]*)(style\s*=\s*"[^"]*")?([^>]*>)', '<th>', err_msg)
    err_msg = re.sub(r'(<td\b[^>]*)(style\s*=\s*"[^"]*")?([^>]*>)', '<td>', err_msg)


    err_msg = initial_message + err_msg

    # add inline styles to make it work in Outlook
    for html_tag, html_style in css_styles.items():
      err_msg = err_msg.replace(html_tag, html_style)
        
    return err_msg
    
  def transform_validation_result(self, test_result:str)->int:
    return int(test_result=="")

  def collect_dq_log(self, schema_result, primary_key_result, nulls_result) -> None:
    schema_result = self.transform_validation_result(schema_result)
    primary_key_result = self.transform_validation_result(primary_key_result)
    nulls_result = self.transform_validation_result(nulls_result)
    
    dq_log = spark.createDataFrame(
      [[
        self.metadata_context["RowKey"],
        self.metadata_context["notebook_current_run_key"],
        datetime.now(),
        schema_result,
        primary_key_result,
        nulls_result
      ]],
      StructType(
            [
                StructField("metadata_code", StringType(), False),
                StructField("notebook_run_key", StringType(), False),
                StructField("log_timestamp", TimestampType(), False),
                StructField("schema_check_result", IntegerType(), False),
                StructField("primary_key_check_result", IntegerType(), False),
                StructField("nulls_check_result", IntegerType(), False),
            ]
        )
    )
    dq_log.write.save(SHARED_DATA_DQ_LOG_PATH , format="avro", mode="append")
    
  def check_dq(self) -> tuple[bool,str]:
    """
    Main method for invoking when trying to update Shared dataset.

    Returns:
      bool: True if DQ gate passed, False otherwise
      str: empty if DQ gate passed, tabulated summary of issues otherwise
    """

    print("Started DQ gate validation for shared dataset...")
    self.check_schemas = self.dq_check_compare_schemas()
    self.check_pk = self.dq_check_primary_key()
    self.check_nulls = self.dq_check_not_nullable_columns()
    
    if self.check_schemas or self.check_pk or self.check_nulls:
      err_msg = self.generate_summary(self.check_schemas, self.check_pk, self.check_nulls)
      display(HTML(err_msg))
      return False, err_msg
    else:
      print("Data Quality gate for Shared dataset successfully passed.")
      return True, ""
    
  def shared_table_writer(self) -> None:
    """
    This function is for writing data to Blob and creating shared table from it
    """
    self.df.write.saveAsTable(name = self.metadata_context["sdl_dbr_table_name"], format = self.metadata_context["file_format"], path = self.metadata_context["sdl_blob_source"], **self.kwargs_for_writing)

  def push_to_sdl(self) -> bool:
    """
    Main method for pushing shared datasets to SDL

    Returns:
      bool: True if DQ gate passed, False otherwise
    """

    res, err_msg = self.check_dq()
    self.collect_dq_log(self.check_schemas, self.check_pk, self.check_nulls)
    
    if res:
      self.shared_table_writer()
      print('Shared dataset successfully written to Blob')
      return True
    else:
      self.send_email(subject = "[metadata handler][error] Shared dataset not loaded due to DQ gate failure", message = err_msg)
      return False
