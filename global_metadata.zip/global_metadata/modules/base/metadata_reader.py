from global_metadata.modules.support.errors import FileFormatError
from global_metadata.modules.support.pandas_to_spark import *
from global_metadata.modules.base.metadata_parser import *
from global_metadata.modules.support.sp_connector import *
from global_metadata.modules.config import *
from typing import Union
import pandas as pd
import pyspark
import glob
import re


class ReadSupportFunctions:
    """
    This class combines support functions for reading data via metadata.

    Methods:
       get_search_pattern - Function that determines the necessary pattern for actions with files based on the passed metadata
       update_from_sharepoint - Function for updating a file from a Sharepoint
       define_kwargs_for_reading - Function for converting additional read parameters that are defined in the metadata
    """

    def __init__(self, metadata_context: dict) -> None:
        self.metadata_context = metadata_context

    @property
    def get_search_pattern(self) -> str:
        """
        Function that determines the necessary pattern for actions with files based on the passed metadata
        This function looks at whether the data is a specific file or a folder with multiple files.
        If it is a file, the pattern will be its name with the extension.
        If it is a file folder, the pattern will be the pattern from the metadata, with the * replaced by
        the passed dynamic pattern plus the extension.
        Files will be searched by matching the name pattern and extension pattern.
        """
        file_name = self.metadata_context["file_name"]
        file_format = self.metadata_context["file_format"]
        if self.metadata_context["is_folder"] == True:
            pattern_search = f"""(.*{file_name}.*){file_format}"""
        else:
            pattern_search = file_name
        return pattern_search

    @property
    def update_from_sharepoint(self) -> None:
        """
        This function downloads files from Sharepoint according to the information in the metadata
        """
        return SharePointBaseConnector_MH(
            username=self.metadata_context["sp_username"],
            password=self.metadata_context["sp_password"],
            sitename=self.metadata_context["sharepoint_name"],
            site_type=self.metadata_context["generic_source"]
        ).download_files_to_blob(
            folder=self.metadata_context["sharepoint_path"]
            .replace("'", "%27%27")
            .replace("`", ""),
            filename_or_mask=self.get_search_pattern.replace("'", "%27%27").replace("`", ""),
            blob_path=self.metadata_context["blob_path"],
            is_folder=self.metadata_context["is_folder"],
        )

    @property
    def define_kwargs_for_reading(self) -> dict:
        """
        Function for converting additional read parameters that are defined in the metadata
        Kwargs in the metadata have the following format kwarg_key1=kwarg_value1&kwarg_key2=kwarg_value2&...
        """
        try:
            kwargs_read = self.metadata_context["kwargs_on_read"].split("&")
            kwargs_read = {
                i.split("=")[0].strip(): i.split("=")[1].strip()
                for i in kwargs_read
                if "=" in i
            }
        except KeyError:
            kwargs_read = {}
            
        if "sheet_name" in self.metadata_context.keys():
            kwargs_read["sheet_name"] = self.metadata_context["sheet_name"]

        return kwargs_read


class Readers(ReadSupportFunctions):
    """
    This class is the object that reads the data itself.
    It determines how to read the data automatically, based on the data format in the metadata.

    An object of this class is callable, i.e. it performs some specific action when the object is created.
    The current class reads data at the moment of object creation
    """

    def __init__(self, metadata_context: dict, kwargs_on_reading: dict) -> None:
        self.metadata_context = metadata_context
        self.metadata_d_types = {
            "xlsx": self.pandas_reader,
            "xlsm": self.pandas_reader,
            "xlsb": self.pandas_reader,
            "csv": self.spark_reader,
            "delta": self.spark_reader,
            "csv.gz": self.spark_reader,
            "parquet": self.spark_reader,
        }
        self.kwargs_on_reading = kwargs_on_reading

    def pandas_reader(self) -> "pd.DataFrame":
        """
        This function reads multiple xlsx/xlsm/xlsb files that have the same passed mask
        in their name and merges them into one common dataframe.

        Returns:
            [pd.DataFrame] : concatenated dataframe with all files

        """
        r_pattern = self.get_search_pattern
        blob_path = self.metadata_context["blob_path"]

        all_files = [
            _
            for _ in glob.glob(f"/dbfs{blob_path}*")
            if bool(re.match(rf"{r_pattern}", _.split("/")[-1]))
        ]

        li = []
        for filename in all_files:
            df = pd.read_excel(filename, **self.kwargs_on_reading)
            li.append(df)

        return pd.concat(li, axis=0, ignore_index=True)

    def spark_reader(self) -> "spark.DataFrame":
        """
        This read method is for the csv/csv.gz/delta/parquet data types and returns the read data.

        Returns:
            [spark.DataFrame] : dataframe with all files
        """
        try:
            return spark.table(self.metadata_context["dbr_table_name"])
        except KeyError:
            file_name = self.metadata_context["file_name"]
            if self.metadata_context["is_folder"] and file_name:
                pattern = f"*{file_name}*"
            else:
                pattern = file_name
            return spark.read.load(
                path=self.metadata_context["blob_path"] + pattern,
                format=self.metadata_context["file_format"].split(".")[0],
                **self.kwargs_on_reading,
            )
    def shared_reader(self) -> "spark.DataFrame":
        """
        Function for reading SHARED data (CDL and SDL)

        Returns:
            [spark.DataFrame] : dataframe with all files
        """

        if self.metadata_context["locality_type"] == "sdl":
            table = "sdl_dbr_table_name"
            blob_path = "sdl_blob_source"
        else:
            table = "dbr_table_name"
            blob_path = "blob_path"

        try:
            return spark.table(self.metadata_context[table])
        except KeyError:
            return spark.read.load(
                path=self.metadata_context[blob_path],
                format=self.metadata_context["file_format"],
                **self.kwargs_on_reading,
            )
        
    def __call__(self):
        if self.metadata_context["is_shared"] and not self.metadata_context["local_only"]:
            return self.shared_reader()
        try:
            return self.metadata_d_types[self.metadata_context["file_format"]]()
        except KeyError:
            f_format = self.metadata_context["file_format"]
            raise FileFormatError(
                f"Format {f_format} is not intended to be handled by metadata. Approved formats: {self.metadata_d_types.keys()}"
            )


class MetadataReader(Readers):

    """
    A class to handle the operation of reading data through metadata,
    it processes information from metadata and returns the read data.

    Class object Args:
        metadata_context[dict]: Metadata related to one specific source (metadata code)
        sp_update[bool]: Marker of whether to update data from a remote source

    Methods:
        get_data - The main method for retrieving data from metadata, ties together all the necessary dependencies

        check_is_folder - Function for determining whether the data is a folder or a specific file
        check_sharepoint_data_update - Checks if there is a need to update data from a remote source (Sharepoint)
        read_data - Returns the read data associated with a specific code in the metadata
        data_convertion - Checks if it is necessary to convert data from spark to pandas and vice versa, if there is such a need, it converts it
    """

    def __init__(self, metadata_context: dict, **kwargs) -> None:
        self.metadata_context = metadata_context

        self.dataframe_type = self.metadata_context["dataframe_type"]

        self.metadata_generic_source_update = {"sharepoint": True, "blob": False, "onedrive": True}
        self.metadata_context["is_folder"] = self.check_is_folder

        self.metadata_context["file_name"] = self.metadata_context["file_name"].replace(
            "*", self.metadata_context["file_mask"]
        )

        self.kwargs_on_reading = {**self.define_kwargs_for_reading, **kwargs}

    @property
    def check_is_folder(self) -> bool:
        """
        Function for determining whether the data is a folder or a specific file
        """
        try:
            file_name = self.metadata_context["file_name"]
        except KeyError:
            file_name = self.metadata_context["file_name"] = ""

        return not file_name.endswith("." + self.metadata_context["file_format"])

    @property
    def check_sharepoint_data_update(self) -> None:
        """
        Checks if there is a need to update data from a remote source (Sharepoint)
        """
        if (
            self.metadata_context["sp_update"]
            and self.metadata_generic_source_update[
                self.metadata_context["generic_source"]
            ]
        ):
            self.update_from_sharepoint

    @property
    def read_data(self) -> Union["pd.DataFrame", "spark.DataFrame"]:
        """
        Returns the read data associated with a specific code in the metadata
        """
        self.check_sharepoint_data_update
        return Readers(self.metadata_context, self.kwargs_on_reading)()

    def data_convertion(self, data) -> Union["pd.DataFrame", "spark.DataFrame"]:
        """
        Checks if it is necessary to convert data from spark to pandas and vice versa, if there is such a need, it converts it
        """
        if isinstance(data, pd.core.frame.DataFrame) and self.dataframe_type == "spark":
            data = pandas_to_spark(data)

        elif (
            isinstance(data, pyspark.sql.dataframe.DataFrame)
            and self.dataframe_type == "pandas"
        ):
            data = data.toPandas()

        return data

    def get_data(self) -> Union["pd.DataFrame", "spark.DataFrame"]:
        """
        The main method for retrieving data from metadata, ties together all the necessary dependencies
        """
        return self.data_convertion(self.read_data)