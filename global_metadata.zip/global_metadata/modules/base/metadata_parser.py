from global_metadata.modules.config import *
from global_metadata.modules.support.tables_connector import *
from global_metadata.modules.support.errors import MetadataConnectionError
from global_metadata.modules.support.sp_connector import *

import json

class MetadataParser:

    """
    This class is designed to retrieve data from the metadata. 
    It is equipped with a protection system and has 3 connection stages.
    The order of connection stages is determined by the order of keys in 
    the dictionary created during initialisation of the class object (connection_priority).

    Methods:
        get_metadata - 
        pull_code_metadata - 
    """

    def __init__(self):
        
        # NOTE: The key order determines the order of connection
        self.connection_priority = {
            "AzureTables": self.__get_metadata_frome_core_source,
            "SharePoint": self.__get_sp_backuped_metadata,
            "Blob": self.__get_blob_backuped_metadata,
        }

        self.table_data = self.__collect_metadata_info()

    def __get_metadata_frome_core_source(self) -> list:
        """Function to retrieve metadata information from Azure Tables"""
        return AzureTablesBaseConnector(
            storage=STORAGE_ACCOUNT, sas_key=TABLES_SAS_KEY_READ, table_api_uri=TABLES_API_WEB_URI
        ).get_table_content(METADATA_CORE_TABLE_NAME)

    def __get_sp_backuped_metadata(self) -> list:
        """Function to retrieve metadata information from Sharepoint Backup"""
        return SharePointBaseConnector_MH(
            SP_USERNAME, SP_PASSWORD, SP_SITE
        ).get_json_file(SP_SH_PATH, SH_FILENAME)

    def __get_blob_backuped_metadata(self) -> list:
        """Function to retrieve metadata information from BLOB Backup"""
        with open("/dbfs" + BLOB_SH_PATH + SH_FILENAME) as f:
            return json.load(f)

    def __check_metadata_access(self, metadata: list) -> list:
        """
        Universal function for checking the success of connection to the metadata
        """
        if "RowKey" in metadata[0].keys():
            return metadata
        else:
            raise MetadataConnectionError(
                "Metadata is not avaliable from this source now."
            )

    @property
    def __sources_viability_handler(self) -> list[dict]:
        """
        Connection management function, it iterates through the connection types one by one 
        and tries to connect to the metadata, if it succeeds, it exits the loop and returns 
        information about the metadata, if it fails, it moves to the next connection type.
        """
        for source, connector in self.connection_priority.items():
            try:
                data = self.__check_metadata_access(connector())
                print(f"Connected with {source}")
                break
            except Exception:
                data = None

        return data
    
    def __tranform_str_to_list(self, metadata: list[dict]) -> list[dict]:
        """
        This function transforms metadata attributes from string to list (e.g. list of email recipients)
        """

        attrs_to_transform = ('owners', 'editors', 'primary_key')

        for item in metadata:
            for atr in attrs_to_transform:
                if atr in item.keys():
                    modified = re.sub(r"[\[\]']", "", item[atr]).split(',')
                    item[atr] = [_.strip() for _ in modified]
        
        return metadata

    def __transform_metadata(self, metadata: list[dict]) -> dict:
        """
        The function converts metadata information into a more convenient form, 
        from a list of dictionaries to a dictionary where the key is the metadata code 
        and the value is the information on that code.
        """

        metadata = self.__tranform_str_to_list(metadata)
        return {_['RowKey']: _ for _ in metadata}

    def __collect_metadata_info(self) -> dict:
        """
        Function to get all the information from the metadata in the desired form
        """
        data = self.__sources_viability_handler

        if data:
            return self.__transform_metadata(data)
        else:
            raise MetadataConnectionError(
                "Metadata is not avaliable from all sources now."
            )

    @property
    def get_metadata(self) -> dict:
        """
        Function returning metadata for all keys
        """
        return self.table_data

    def pull_code_metadata(self, metadata_code: str) -> dict:
        """
        Function for obtaining metadata on a specific key
        """
        return self.table_data[metadata_code]