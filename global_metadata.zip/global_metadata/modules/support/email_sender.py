import requests
from pyspark.dbutils import DBUtils
from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()
dbutils = DBUtils(spark)

class EmailSender:

    """
    Toolkit for sending email messages.

    This class accepts parameters for authorisation in the Graph API when creating an object.

    Methods:

    set_message  - Sets the text of the message to be sent
    set_subject - Sets the subject of the message to be sent
    set_recipients - Sets the list of recipients
    set_bbc_recipients - Sets the recipient list in a hidden copy

    send_email - Sends a message with the set parameters

    """

    def __init__(
        self,
        client_id: str = dbutils.secrets.get('lp14dv', 'EmailSender-Client-ID'),
        tenant_id: str = dbutils.secrets.get('lp14dv', 'EmailSender-Tenant-ID'),
        client_secret: str = dbutils.secrets.get('lp14dv', 'EmailSender-AppToken'),
    ) -> None:

        self.sender: str = "eedatahub.im@pg.com"
        self.client_id = client_id
        self.tenant_id = tenant_id
        self.client_secret = client_secret

        self.body = {"message": {"body": {}}}
        self.header = {}

    def check_type(self, val, target_type) -> None:
        """
        This function is intended to check if the variable corresponds to the passed type

        Args:
            val [Any] : Variable of any type to check matching
            target_type [Any, python type object]: Data type to compare the variable with

        Returns: 
            None

        Raises:
            TypeError - If the type of the passed variable does not match the type with which the comparison should be made

        """
        if not isinstance(val, target_type):
            raise TypeError(
                f"Ivalid data type, must be {str(target_type)} not {str(type(val))}"
            )

    def set_message(self, message: str):
        """
        Function for setting the message text in the sent e-mail message

        Args:
            message[str]: The text of the message to be sent
        Return:
            Modified class object
        """
        self.check_type(message, str)
        self.body["message"]["body"]["content"] = message
        return self

    def set_subject(self, subject: str):
        """
        Function for setting the message subject in the sent e-mail message

        Args:
            subject[str]: The subject of the message to be sent
        Return:
            Modified class object
        """
        self.check_type(subject, str)
        self.body["message"]["subject"] = subject
        return self

    def set_recipients(self, recipients: list):
        """
        Function for setting the list of recipients in the sent e-mail message

        Args:
            recipients[list]: List of emails with users who will receive the message
        Return:
            Modified class object
        """
        self.check_type(recipients, list)
        self.body["message"]["toRecipients"] = [
            {"EmailAddress": {"Address": address}} for address in recipients
        ]
        return self

    def set_bbc_recipients(self, bbc_recipients: list):
        """
        Function for setting the list of hidden recipients in the sent e-mail message

        Args:
            bbc_recipients[list]: List of emails with users who will receive the message in hidden copy
        Return:
            Modified class object
        """
        self.check_type(bbc_recipients, list)
        self.body["message"]["bccRecipients"] = [
            {"EmailAddress": {"Address": address}} for address in bbc_recipients
        ]
        return self

    @property
    def __auth(self) -> "requests.session":
        """
        Method for performing authontification in the API with the help of which messages are sent
        """
        s = requests.session()
        auth_url = (
            f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
        )
        auth_data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "scope": "https://graph.microsoft.com/.default",
            "grant_type": "client_credentials",
        }
        token = s.post(auth_url, data=auth_data).json()["access_token"]
        self.header["Authorization"] = f"Bearer {token}"
        return s

    def send_email(self, content_type: str = "Text"):
        """
        Method for sending messages with accumulated parameters

        Kwargs:
            content_type[str] (Default == Text): The type of message to be sent, by default text, but can otherwise take Html format as well
        """
        url_for_sending = (
            f"https://graph.microsoft.com/v1.0/users/{self.sender}/sendMail"
        )
        self.body["message"]["body"]["contentType"] = content_type
        session = self.__auth
        return session.post(url_for_sending, headers=self.header, json=self.body)