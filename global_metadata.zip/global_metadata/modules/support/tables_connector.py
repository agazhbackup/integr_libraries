import requests
import json
from global_metadata.modules.config import *


class AzureTablesBaseConnector:
    """
    This class is designed to manipulate Azure Tables using the Table Storage API

    Class object init params:
        storage[str]: storage account name
        sas_key[str]: table access key, required for authorisation
        table_api_uri[str]: api unique identifier that will be accessed

    Methods:
        get_table_content - API GET method for extracting information from table
        put_table_content - API POST method for merge-insert operation on needed row (RowKey+PartitionKey = Table primary key)
        delete_row_content - API DELETE method to delete information on a specific row
    """

    def __init__(self, storage: str, sas_key: str, table_api_uri: str = TABLES_API_WEB_URI) -> None:
        self.storage = storage
        self.sas_key = sas_key
        self.table_api_uri = table_api_uri
        self.headers = {}

    def get_table_content(self, table_name: str) -> list:

        """
        Method for obtaining information from a Azure metadata tables

        Args:
            table_name[str]: Name of the table from which you want to get information
        Returns:
            list[dict] - List of dictionaries where one dictionary == one row of data
        """
        
        url_base = f"https://{self.storage}.{self.table_api_uri}/{table_name}(){self.sas_key}"
        self.headers["Accept"] = "application/json;odata=nometadata"

        response = requests.get(url_base, headers=self.headers)
        content = json.loads((response.content))['value']

        while True:
            if 'x-ms-continuation-NextRowKey' in response.headers:

                url = url_base + f"&$top=1000&NextPartitionKey={response.headers['x-ms-continuation-NextPartitionKey']}&NextRowKey={response.headers['x-ms-continuation-NextRowKey']}"
                response = requests.get(url, headers=self.headers)

                temp = json.loads((response.content))['value']
                content.extend(temp)
            else:
                break

        return content
    
    def get_filter_table_content(self, table_name: str, filter_by_property: str, property_value: str) -> list[dict]:
        """
        Method for obtaining information from a Azure metadata tables, filtered by specific column

        Args:
            table_name[str]: Name of the table from which you want to get information
            filter_by_property[str]: name of the column to filter by
            property_value[str]: value to filter by
        Returns:
            list[dict] - List of dictionaries where one dictionary == one row of data
        """

        url = f"https://{self.storage}.{self.table_api_uri}/{table_name}(){self.sas_key}&$filter={filter_by_property}%20eq%20'{property_value}'%20"
        self.headers["Accept"] = "application/json;odata=nometadata"
        response = requests.get(url, headers=self.headers)
        content = json.loads((response.content))
        return content["value"]

    def put_table_content(self, table_name: str, content: dict) -> int:
        """
        Method for putting information in a Azure metadata tables

        Args:
            table_name[str]: Name of the table in which you want to put the information
            content[dict]: The information you want to put in the table as a dictionary, where key is the column name, value is the value for that row
        Returns:
            int - Result status code
        """
        url = f"https://{self.storage}.{self.table_api_uri}/{table_name}(PartitionKey='{content['PartitionKey']}', RowKey='{content['RowKey']}'){self.sas_key}"
        self.headers["Accept"] = "application/json;odata=nometadata"
        self.headers["Content-Type"] = "application/json"
        response = requests.patch(url, headers=self.headers, json=content)
        return response.status_code

    def delete_row_content(self, table_name: str, content: dict) -> int:
        """
        Method for deleting information from a Azure metadata tables

        Args:
            table_name[str]: Name of the table in which you want to delete the information
            content[dict]: The information you want to delete from the table as a dictionary, where key is the column name, value is the value for that row
            From all information only RowKey and PartitionKey are needed, other values will be deleted when these two parameters match.
        Returns:
            int - Result status code
        """
        url = f"https://{self.storage}.{self.table_api_uri}/{table_name}(PartitionKey='{content['PartitionKey']}', RowKey='{content['RowKey']}'){self.sas_key}"
        self.headers["Accept"] = "application/json;odata=nometadata"
        self.headers["If-Match"] = "*"
        response = requests.delete(url, headers=self.headers)
        return response.status_code