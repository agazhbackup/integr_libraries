# Databricks notebook source
# MAGIC %pip install croniter

# COMMAND ----------

import re
import dlt
import croniter

from global_metadata.modules.config import *
from pyspark.sql import functions as f
from pyspark.sql.window import Window
from datetime import datetime

# COMMAND ----------

@f.udf
def transfer_cron_to_datetime(val:str, base:"datetime")->str:
    """Function for transforming cron syntax into date-time, base on passed value(base date)"""
    if val == "* * * * * *":
        return base.strftime("%Y-%m-%d %H:%M:%S")
    elif val:
        val_conv = val.replace("?", "*").split(" ")
        val_conv.append(val_conv.pop(0))
        cron = croniter.croniter(" ".join(val_conv), base)
        return cron.get_next(datetime).strftime(
            "%Y-%m-%d %H:%M:%S"
        )

# COMMAND ----------

@f.udf
def handle_refresh_duration(val):
  """Function for transforming refresh duration in to number of minutes"""
  pattern = r'(\d+(\.\d+)?)(m|h)'
  match = re.search(pattern, val)

  if val.endswith("h"):
    k=60
  else:
    k=1

  if match:
      return float(match.group(1)) * k
  else:
      return None

# COMMAND ----------

@dlt.view(
    comment="Initial table with logs of data usage in code. Collected by metadata handler lib"
)
def initial_metadata_logs():
    return (
        spark.read.load(LOG_COLLECTION_PATH, format="AVRO")
        .withColumn("log_timestamp",f.col("log_timestamp") + f.expr("INTERVAL 3 HOURS"))
        .withColumns(
            {
                "time_period_end_date": f.to_date(f.col("log_timestamp")),
                "is_called_from_repo": f.col("notebook_path")
                .startswith("/Repos/")
                .cast("integer"), 
            }
        )
       
    )

# COMMAND ----------

@dlt.view(comment="Initial table with logs of Data Quality results for shared data")
def initial_shared_data_dq_result():
    return (
        spark.read.load(SHARED_DATA_DQ_LOG_PATH, format="AVRO")
        .withColumn("log_timestamp",f.col("log_timestamp") + f.expr("INTERVAL 3 HOURS"))
        .withColumns(
            {
                "func_name": f.lit("write_file"),
                "last_check": f.last("log_timestamp").over(
                    Window.partitionBy("metadata_code", "notebook_run_key")
                ),
            }
        )
        .filter(f.col("log_timestamp") == f.col("last_check"))
    ).drop("last_check")

# COMMAND ----------

@dlt.view(comment="Log table with pre calculated logs with logics for run dates")
def joined_log_table():

    # reading current metadata snapshot
    metadata = spark.table(DELTA_SH_TABLE_NAME)

    # reading pre-processed tables and merge logs with shared data DQ logs
    df_main = dlt.read("initial_metadata_logs").join(
        dlt.read("initial_shared_data_dq_result").withColumnRenamed(
            "log_timestamp", "dq_timestamp"
        ),
        ["metadata_code", "notebook_run_key", "func_name"],
        "left",
    )

    # Join with metadata for calculation Next update target date-time
    # Target date-time based on previous run date time. Using CRON syntax, we calculate target refresh date-time
    # First, for each log row we calc previous run date-time( lag window fucntion ). If there is no prev date, we takes current date - 1 day
    # Then we calculate expected_refresh_timestamp for all write operations using custom UDFs (as target refresh start date + duration)
    df_calculated = (
        df_main.join(
            metadata.select(
                f.col("RowKey").alias("metadata_code"),
                "refresh_schedule",
                "refresh_duration",
            ),
            ["metadata_code"],
        )
        .withColumn(
            "prev_write",
            f.coalesce(
                f.lag("log_timestamp").over(
                    Window.partitionBy(
                        "metadata_code", "func_name", "databricks_env_key"
                    ).orderBy("log_timestamp")
                ),
                f.date_sub(f.col("log_timestamp"), 1),
            ),
        )
        .withColumn(
            "prev_write",
            f.when(f.col("refresh_schedule") == "* * * * * *", f.col("log_timestamp"))
            .otherwise(f.col("prev_write"))
        )
        .withColumn(
            "refresh_duration", handle_refresh_duration(f.col("refresh_duration"))
        )
        .withColumn(
            "expected_refresh_timestamp",
            f.when(
                f.col("func_name") == "write_file",
                transfer_cron_to_datetime(
                    f.col("refresh_schedule"), f.col("prev_write")
                )
                + f.col("refresh_duration") * f.expr("INTERVAL 1 MINUTES"),
            ).cast("timestamp"),
        )
        .drop("prev_write", "refresh_duration", "refresh_schedule")
    )

    # calculate min refresh date(min date of data operation in current day)
    # calculate marker for checking is data refreshed in time (1\0)
    return df_calculated.withColumn(
        "min_refresh_date",
        f.first(f.col("log_timestamp")).over(
            Window.partitionBy(
                "metadata_code",
                "func_name",
                "databricks_env_key",
                "time_period_end_date",
            )
        ),
    ).withColumn(
        "is_refreshed_in_time",
        (f.col("min_refresh_date") <= f.col("expected_refresh_timestamp")).cast(
            "integer"
        ),
    )

# COMMAND ----------

@dlt.table(comment="Log table with dq results for shared data", name="data_usage_log")
def final_log_table():
    # reading current metadata snapshot
    metadata = spark.table(DELTA_SH_TABLE_NAME).select(
        f.col("RowKey").alias("metadata_code"),
        f.col("application_id").alias("project_name"),
    )

    # reading pre-processed tables and merge logs with shared data DQ logs
    df_main = dlt.read("joined_log_table")

    df_target_keys = (
        (
            df_main.filter(f.col("func_name") == "write_file")
            .select("notebook_run_key", "metadata_code")
            .join(
                metadata,
                ["metadata_code"],
            )
        )
        .select("notebook_run_key", "project_name")
        .drop_duplicates(["notebook_run_key"])
    )

    return df_main.join(df_target_keys, ["notebook_run_key"], "left").na.fill(
        value="Can't define", subset=["project_name"]
    )

# COMMAND ----------

@dlt.table(
    comment="Table with source-target lookup for metadata code by each notebook run key",
    name="data_relationships_log",
)
def metadata_source_target_lookup():
    data = dlt.read("data_usage_log")
    metadata = spark.table(DELTA_SH_TABLE_NAME).select(
        f.col("RowKey").alias("metadata_code"),
        "is_technical",
    )
    exclude_runs = (
        data.join(metadata, ["metadata_code"])
        .filter(f.col("is_technical") == True)
        .select("notebook_run_key")
        .distinct()
    )

    df_target_keys = (
        data.filter(f.col("func_name") == "write_file")
        .select(
            "notebook_run_key", f.col("metadata_code").alias("target_metadata_code")
        )
        .distinct()
    )
    df_source_keys = (
        data.filter(f.col("func_name") != "write_file")
        .select(
            "notebook_run_key", f.col("metadata_code").alias("source_metadata_code")
        )
        .distinct()
    )
    return (
        df_target_keys.join(df_source_keys, "notebook_run_key")
        .filter(f.col("target_metadata_code") != f.col("source_metadata_code"))
        .join(exclude_runs, ["notebook_run_key"], "left_anti")
    )