# Databricks notebook source
from global_metadata.modules.config import *
from global_metadata.modules.support.tables_connector import AzureTablesBaseConnector
from global_metadata.modules.support.sp_connector import *
from multiprocessing.pool import ThreadPool
import json

# COMMAND ----------

def extract_distinct_field(data_d: list[dict], field: str) -> set:
    return set([_[field] for _ in data_d])


def search_by_content(data_d: list[dict], values: set, field: str) -> list[dict]:
    return [_ for _ in data_d if _[field] in values]


def clean_redundant_codes(codes_for_delete: list[dict]) -> list:
    """Deleting codes from metadata schema using multitread"""
    delete_session = AzureTablesBaseConnector(
        storage=STORAGE_ACCOUNT,
        sas_key=TABLES_SAS_KEY_WRITE,
        table_api_uri=TABLES_API_WEB_URI,
    )
    pool = ThreadPool(len(codes_for_delete))
    return pool.map(
        func=lambda table_content: delete_session.delete_row_content(
            METADATA_SCHEMA_REGISTRY_NAME, table_content
        ),
        iterable=codes_for_delete,
    )

# COMMAND ----------

# DBTITLE 1,Get current metadata table json
table_session = AzureTablesBaseConnector(
    storage=STORAGE_ACCOUNT, sas_key=TABLES_SAS_KEY_READ, table_api_uri=TABLES_API_WEB_URI
)
current_metadata = table_session.get_table_content(METADATA_CORE_TABLE_NAME)

# COMMAND ----------

# DBTITLE 1,Get schema table json
schema_metadata = table_session.get_table_content(METADATA_SCHEMA_REGISTRY_NAME)

# COMMAND ----------

# DBTITLE 1,Delete codes that deleted from metadata and still exist in schema
metadata_codes_in_registry = extract_distinct_field(current_metadata, "RowKey")
metadata_codes_in_schema = extract_distinct_field(schema_metadata, "PartitionKey")
redundant_codes = metadata_codes_in_schema - metadata_codes_in_registry

if redundant_codes:
    codes_for_delete = search_by_content(
        schema_metadata, redundant_codes, "PartitionKey"
    )

    del_res = clean_redundant_codes(codes_for_delete)
    print(f"Deleted: {len([_ for _ in del_res if _ == 204])} / {len(del_res)}")
else:
    print("All codes sync")

# COMMAND ----------

# DBTITLE 1,Save metadata snapshot on SP
sp_session = SharePointBaseConnector_MH(username=SP_USERNAME, password=SP_PASSWORD, sitename=SP_SITE)
sp_session.post_json_file(current_metadata, SP_SH_PATH, SH_FILENAME)

# COMMAND ----------

# DBTITLE 1,Save metadata shapshot on Blob
dbutils.fs.mkdirs(BLOB_SH_PATH)
with open("/dbfs" + BLOB_SH_PATH + SH_FILENAME, "w") as f:
    json.dump(current_metadata, f)

# COMMAND ----------

# DBTITLE 1,Save matadata as delta table on blob
df_metadata = spark.createDataFrame(current_metadata)
df_metadata.write.saveAsTable(DELTA_SH_TABLE_NAME, path=DELTA_SH_PATH, partitionBy="PartitionKey", mode="overwrite", overwriteSchema=True)

# COMMAND ----------

# DBTITLE 1,Save schema snapshot
df_schema_metadata = spark.createDataFrame(schema_metadata)
df_schema_metadata.write.saveAsTable(DELTA_SCHEMA_SH_TABLE_NAME, path=DELTA_SCHEMA_SH_PATH, mode="overwrite", overwriteSchema=True)