# Databricks notebook source
from global_metadata.modules.base.metadata_inputer import *

# COMMAND ----------

# DBTITLE 1,widget setup
# primary features
dbutils.widgets.text(name='RowKey', defaultValue='', label='metadata_code')

# binary flags
dbutils.widgets.dropdown('is_active', '', ['', 'True', 'False'])  #whether the metadata code is active (True) or not (False)
dbutils.widgets.dropdown('is_raw', '', ['', 'True', 'False'])  #whether the data is raw (True) or refined (False)

# development cycle
dbutils.widgets.dropdown('source_lp_id', '', ['', 'lp-11dv','lp-13dv','lp-13ut', 'lp-14dv', 'lp-17dv','lp-18dv','lp-23ut','lp-23dv','lp-11prod','lp-13prod','lp-17prod','lp-18prod','lp-23prod'])
dbutils.widgets.text('application_id', '')  #sdl/cdl or EE app ID from inventory
dbutils.widgets.text('owners', '')  #who is reposnible for the data

# storage
dbutils.widgets.text('blob_path', '')  #path to blob in a format /mnt/blob/lp/[container]/[folder]/[subfolder]/
dbutils.widgets.dropdown('file_format', '', ['', 'delta', 'csv', 'xlsx', 'parquet', 'xlsm', 'xlsb', 'csv.gz'])
dbutils.widgets.text('primary_key', '')  #[site_key, prod_key] 
dbutils.widgets.text('refresh_schedule', '')  #use quartz CRON 
dbutils.widgets.text('refresh_duration', '')  #number of hours it takes to refresh the data. example: 4h 
dbutils.widgets.text('retention_policy', '') #how long the data can/should be preserved: 36mm (36 months)

# context
dbutils.widgets.dropdown('generic_source', '', ['', 'blob', 'sharepoint', 'onedrive'])
dbutils.widgets.dropdown('type', '', ['', 'fact', 'master', 'lookup', 'meta'])  #master, fact, lookup, metadata
dbutils.widgets.dropdown('iaf_data_type', '', ['', "Calendar of Events", "Financial Master Data", "Customer / Distributor / Wholesaler", "Information Technology (IT)", "Shipment", "Material Goods", "Store", "Distributor Sales & Supply Chain", "Customer Commercial Agreement", "Customer Sales & Supply Chain (POS)", "Trade Panel", "Management Reporting", "Digital Commerce", "Go to Market", "Sales Management", "Price", "Supply Chain"])  #please consult the following link for correct classification: https://ease.pg.com/tree/prod/content/hierarchy_content.php
dbutils.widgets.dropdown('data_classification', '', ['', 'Highly Restricted', 'Business Use'])  #please consult the following link for correct classification: https://ease.pg.com/tree/prod/content/hierarchy_content.php
dbutils.widgets.text('description', '')

# optional fields
dbutils.widgets.text('file_name', '', label='optional') 
dbutils.widgets.text('sharepoint_name', '', label='optional')
dbutils.widgets.text('sharepoint_path', '', label='optional') 
dbutils.widgets.text('sheet_name', '', label='optional') #name of the file sheet in case of excel files
dbutils.widgets.text('dbr_table_name', '', label='optional') #db_name.table_name
dbutils.widgets.text('kwargs_on_read', '', label='optional')  #kwarg_key1=kwarg_value1&kwarg_key2=kwarg_value2&...
dbutils.widgets.text('kwargs_on_write', '', label='optional')  #kwarg_key1=kwarg_value1&kwarg_key2=kwarg_value2&...

# COMMAND ----------

metadata = MetadataInput()
metadata.push_metadata()